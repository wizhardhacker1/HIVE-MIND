@echo off
setlocal
cd /d "%~dp0"
title HIVE MIND Memory Installer
echo Starting HIVE MIND Memory installer...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL_HIVE_MIND.ps1"
if errorlevel 1 (
  echo.
  echo INSTALLATION FAILED. Review the error above and install.log under %%LOCALAPPDATA%%\HIVE MINDMemory if present.
  pause
  exit /b 1
)
exit /b 0
