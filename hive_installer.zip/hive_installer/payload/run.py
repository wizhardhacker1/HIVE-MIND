import os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
os.chdir(ROOT)
sys.path.insert(0,str(ROOT/'backend'))
# A validated restore is applied before SQLAlchemy opens the live SQLite database.
from app.services.backup import apply_pending_restore
try:
    if apply_pending_restore():
        print('HIVE MIND: staged backup restore applied successfully.')
except Exception as e:
    print('HIVE MIND: pending restore was NOT applied:',e)
import uvicorn
from app.config import settings
uvicorn.run('app.main:app',host=settings.host,port=settings.port,reload=False)
