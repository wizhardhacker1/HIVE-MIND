let csrf='',me=null,current=null,vaultList=[],chatController=null,chatBusy=false,chatMode='auto';const $=s=>document.querySelector(s);
async function api(url,opt={},_csrfRetry=false){
  opt.headers=opt.headers||{};
  const method=(opt.method||'GET').toUpperCase(),stateChanging=['POST','PATCH','DELETE','PUT'].includes(method);
  if(stateChanging&&csrf)opt.headers['X-CSRF-Token']=csrf;
  let r=await fetch(url,opt),ct=r.headers.get('content-type')||'',data=ct.includes('json')?await r.json():await r.text();
  if(r.status===403&&stateChanging&&!_csrfRetry&&data&&data.detail==='CSRF validation failed'){
    try{const fresh=await fetch('/api/auth/me');if(fresh.ok){const fm=await fresh.json();csrf=fm.csrf||csrf;opt.headers['X-CSRF-Token']=csrf;return api(url,opt,true)}}catch(_){}
  }
  if(!r.ok)throw Error(data.detail||data||r.statusText);
  return data
}
function toast(t){let x=$('#toast');x.textContent=t;x.style.opacity=1;setTimeout(()=>x.style.opacity=0,2600)}
function esc(t){return String(t??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function setWorkspaceMode(mode){const cw=$('.chatwrap');if(cw)cw.classList.toggle('hidden',mode!=='chat');document.querySelectorAll('.tabs button[data-action]').forEach(b=>b.classList.remove('active'));const map={chat:'show-chat',documents:'load-docs',settings:'show-settings',access:'show-access'};if(map[mode]){const b=document.querySelector(`.tabs button[data-action=\"${map[mode]}\"]`);if(b)b.classList.add('active')}}
function openPanel(mode){setWorkspaceMode(mode||'panel');$('#panel').classList.remove('hidden')}
function downloadAudit(format){const a=document.createElement('a');a.href=`/api/audit/export?format=${encodeURIComponent(format)}`;a.download='';document.body.appendChild(a);a.click();a.remove()}
async function init(){let s=await api('/api/setup/status');try{let m=await api('/api/auth/me');signed(m)}catch{if(s.required){$('#authText').textContent='Create the first local administrator';$('#display').classList.remove('hidden');$('#authBtn').textContent='Create administrator';$('#authBtn').onclick=setup}else{$('#authBtn').onclick=login}}}
async function setup(){try{let r=await api('/api/setup/admin',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:$('#username').value,display_name:$('#display').value,password:$('#password').value})});signed(r)}catch(e){$('#authErr').textContent=e.message}}
async function login(){try{let r=await api('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:$('#username').value,password:$('#password').value})});signed(r)}catch(e){$('#authErr').textContent=e.message}}
async function signed(r){me=r.user;csrf=r.csrf;$('#auth').classList.add('hidden');$('#app').classList.remove('hidden');$('#who').textContent=`${me.display_name} · ${me.role}`;checkLlmStatus();if(me.must_change_password){let oldp=prompt('Your temporary password must be changed. Enter the current password.');let newp=prompt('Enter a new password (14+ chars, upper/lower/number/symbol).');if(!oldp||!newp){await logout();return}try{await api('/api/auth/change-password',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({current_password:oldp,new_password:newp})});me.must_change_password=false;toast('Password changed')}catch(e){alert(e.message);await logout();return}}loadVaults()}
async function logout(){await api('/api/auth/logout',{method:'POST'});location.reload()}
async function loadVaults(){vaultList=await api('/api/vaults');$('#vaults').innerHTML=vaultList.map(v=>`<button class="vault" data-action="select-vault" data-id="${v.id}">${esc(v.name)}<small>${esc(v.title||v.department||'Knowledge vault')} · ${v.documents} docs</small></button>`).join('')||'<p class="muted">No vaults</p>'}
function selectVault(id){current=vaultList.find(v=>v.id===id);$('#empty').classList.add('hidden');$('#panel').classList.add('hidden');$('#workspace').classList.remove('hidden');setWorkspaceMode('chat');$('#vaultName').textContent=current.name;$('#vaultMeta').textContent=[current.title,current.department,`${current.documents} documents`].filter(Boolean).join(' · ');$('#uploadLabel').style.display=current.permissions.upload?'inline-block':'none';loadDocs();loadChatHistory()}
async function newVault(){if(!['admin','knowledge_admin'].includes(me.role))return toast('Your role cannot create vaults');let name=prompt('Employee / vault name');if(!name)return;let title=prompt('Title (optional)')||null;let department=prompt('Department (optional)')||null;await api('/api/vaults',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,title,department})});await loadVaults();toast('Vault created')}
$('#fileInput').addEventListener('change',async e=>{const files=[...e.target.files];e.target.value='';await uploadFiles(files)});
function docCards(docs,selectable=false){
  return docs.length?docs.map(d=>`<div class="source document-row" data-doc-id="${d.id}">
    ${selectable&&current&&current.permissions.manage?`<label class="doc-check-wrap" title="Select ${esc(d.filename)}"><input class="doc-select" type="checkbox" value="${d.id}" aria-label="Select ${esc(d.filename)}"></label>`:''}
    <div class="doc-info"><b>${esc(d.filename)}</b><small>${esc(d.source_type)} · ${(d.size_bytes/1024).toFixed(1)} KB · ${esc(d.malware_status)}</small><span class="badge ${d.sensitivity==='restricted'?'restricted':''}">${esc(d.sensitivity)}</span> <a href="/api/documents/${d.id}/download" target="_blank">download</a>${current&&current.permissions.manage&&!selectable?` <button class="danger" data-action="delete-doc" data-id="${d.id}">Delete</button>`:''}</div>
  </div>`).join(''):'<p class="muted">No documents indexed.</p>'
}
async function uploadFiles(files){if(!current||!files.length)return;const panel=$('#panel');$('#panelTitle').textContent='Importing Documents';$('#panelBody').innerHTML=`<div class="stat"><b>Upload in progress</b><p>${files.length} file(s) are being validated, encrypted, parsed, and indexed.</p></div>`;panel.classList.remove('hidden');let fd=new FormData();files.forEach(f=>fd.append('files',f));try{let r=await api(`/api/vaults/${current.id}/upload`,{method:'POST',body:fd});let ok=r.filter(x=>!x.error),bad=r.filter(x=>x.error);$('#panelTitle').textContent='Import Results';$('#panelBody').innerHTML=`<div class="grid"><div class="stat"><b>Indexed</b><p>${ok.length}</p></div><div class="stat"><b>Rejected / failed</b><p>${bad.length}</p></div></div><h3>Files</h3>${r.map(x=>`<div class="source"><b>${esc(x.filename)}</b>${x.error?`<small style="color:#ff9ca7">${esc(x.error)}</small>`:`<small>${x.duplicate?'Already indexed (duplicate)':`${x.chunks} chunk(s) indexed`} · ${esc(x.source_type)} · ${esc(x.sensitivity)}</small>`}</div>`).join('')}<button class="smallbtn" data-action="show-documents">View Documents</button>`;await loadVaults();current=vaultList.find(v=>v.id===current.id);await loadDocs();toast(bad.length?`${ok.length} indexed; ${bad.length} failed`:`${ok.length} indexed successfully`)}catch(err){$('#panelTitle').textContent='Import Failed';$('#panelBody').innerHTML=`<div class="source"><b>Upload failed</b><small style="color:#ff9ca7">${esc(err.message)}</small></div>`;toast('Upload failed: '+err.message)}}
async function loadDocs(){if(!current)return;let docs=await api(`/api/vaults/${current.id}/documents`);$('#sources').innerHTML=docCards(docs);return docs}
async function showDocuments(){
  if(!current)return toast('Select a vault');
  let docs=await loadDocs();
  $('#panelTitle').textContent=`Documents — ${current.name}`;
  const canManage=!!current.permissions.manage;
  $('#panelBody').innerHTML=`
    <div class="documents-toolbar">
      <div><b>${docs.length}</b> stored document(s)</div>
      <div class="doc-actions">
        <label class="smallbtn">＋ Import More<input id="panelFileInput" type="file" multiple hidden></label>
        ${canManage&&docs.length?`<button class="smallbtn" data-action="select-all-docs">Select All</button>
        <button class="smallbtn" data-action="select-none-docs">Select None</button>
        <button class="danger bulk-delete-btn" data-action="delete-selected-docs" disabled>Delete Selected <span id="selectedDocCount">(0)</span></button>
        <button class="danger-outline" data-action="delete-all-docs">Delete All in Vault</button>`:''}
      </div>
    </div>
    <p class="muted">Files remain encrypted at rest and indexed for local retrieval. Bulk delete removes the selected originals and their index chunks in one operation.</p>
    <div id="documentList">${docCards(docs,true)}</div>`;
  openPanel('documents');
  setTimeout(()=>{
    let x=$('#panelFileInput');
    if(x)x.addEventListener('change',async e=>{const fs=[...e.target.files];e.target.value='';await uploadFiles(fs)});
    document.querySelectorAll('.doc-select').forEach(c=>c.addEventListener('change',updateBulkSelection));
    updateBulkSelection();
  },0)
}
function selectedDocumentIds(){return [...document.querySelectorAll('.doc-select:checked')].map(x=>Number(x.value)).filter(Number.isInteger)}
function updateBulkSelection(){
  const ids=selectedDocumentIds(),count=$('#selectedDocCount'),btn=document.querySelector('[data-action="delete-selected-docs"]');
  if(count)count.textContent=`(${ids.length})`;
  if(btn)btn.disabled=ids.length===0
}
function selectAllDocuments(checked){
  document.querySelectorAll('.doc-select').forEach(x=>x.checked=checked);
  updateBulkSelection()
}
async function bulkDeleteDocuments(deleteAll=false){
  if(!current||!current.permissions.manage)return toast('Vault manage permission required');
  const ids=deleteAll?[]:selectedDocumentIds();
  if(!deleteAll&&!ids.length)return toast('Select one or more documents');
  const message=deleteAll
    ?`Delete ALL documents from "${current.name}"?\n\nThis removes every stored original and index entry in this vault. This cannot be undone except by restoring a backup.`
    :`Delete ${ids.length} selected document${ids.length===1?'':'s'}?\n\nThis removes the stored originals and index entries.`;
  if(!confirm(message))return;
  if(deleteAll){
    const typed=prompt(`Type DELETE ALL to confirm deleting every document in "${current.name}".`);
    if(typed!=='DELETE ALL')return toast('Delete All cancelled')
  }
  const r=await api(`/api/vaults/${current.id}/documents/bulk-delete`,{
    method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({document_ids:ids,delete_all:deleteAll})
  });
  toast(`${r.deleted} document${r.deleted===1?'':'s'} deleted`);
  await loadVaults();
  current=vaultList.find(v=>v.id===current.id)||current;
  await showDocuments()
}
async function deleteDoc(id){
  if(!confirm('Delete this document from HIVE MIND?'))return;
  await api(`/api/documents/${id}`,{method:'DELETE'});
  await loadVaults(); current=vaultList.find(v=>v.id===current.id)||current;
  await loadDocs(); toast('Document deleted')
}
function addMsg(role,text){let m=document.createElement('div');m.className='msg '+role;m.innerHTML=`<div class="avatar">${role==='user'?'Y':'H'}</div><div><b>${role==='user'?'YOU':'HIVE'}</b><p>${esc(text)}</p></div>`;$('#messages').appendChild(m);$('#messages').scrollTop=$('#messages').scrollHeight;return m}
function setChatBusy(v){chatBusy=v;$('#sendBtn').disabled=v;$('#stopBtn').classList.toggle('hidden',!v);$('#q').disabled=v}
function stopChat(){if(chatController){chatController.abort();chatController=null}setChatBusy(false);toast('Response stopped')}
async function checkLlmStatus(){let el=$('#llmStatus');if(!el)return;el.className='llm-status checking';el.textContent='LLM CHECKING';try{let r=await api('/api/llm/status');if(r.reachable&&r.model_available){el.className='llm-status online';el.textContent='LOCAL AI · LLAMA 3.2 3B'}else if(r.reachable){el.className='llm-status offline';el.textContent='LLAMA 3.2 MISSING';el.title=`Ollama is running, but ${r.model} is not installed.`}else{el.className='llm-status offline';el.textContent='LOCAL AI OFFLINE';el.title=r.detail||'Local LLM is unavailable'}}catch(e){el.className='llm-status offline';el.textContent='LOCAL AI OFFLINE';el.title=e.message}}
async function ask(){if(chatBusy)return;if(!current)return toast('Select a vault');let q=$('#q').value.trim();if(!q)return;$('#q').value='';addMsg('user',q);let waiting=chatMode==='general'?'Thinking with local AI…':chatMode==='vault'?'Searching encrypted vault knowledge…':'Choosing the best answer mode…';let m=addMsg('ai',waiting);chatController=new AbortController();setChatBusy(true);try{let r=await api('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({vault_id:current.id,question:q,mode:chatMode}),signal:chatController.signal});m.querySelector('p').textContent=r.answer;let badge=r.resolved_mode==='general'?'GENERAL AI · NOT VAULT GROUNDED':`${r.evidence.toUpperCase()} EVIDENCE · VAULT`;m.querySelector('div:last-child').insertAdjacentHTML('beforeend',`<span class="badge ${r.resolved_mode==='general'?'general-ai':''}">${badge}</span>${r.answer_mode==='evidence_fallback'?`<div class="chat-fallback-note">Local AI could not complete this request; HIVE MIND returned a concise evidence fallback. Sources remain available on the right.</div>`:''}`);$('#sources').innerHTML=r.resolved_mode==='general'?'<p class="muted"><b>General Chat</b><br>No vault records were sent to the model for this answer.</p>':(r.sources.map(s=>`<div class="source"><b>[${s.n}] ${esc(s.filename)}</b><small>${esc(s.source_type)} · relevance ${s.score}</small><span class="badge ${s.sensitivity==='restricted'?'restricted':''}">${esc(s.sensitivity)}</span> <a href="/api/documents/${s.document_id}/download" target="_blank">open</a></div>`).join('')||'<p class="muted">No evidence found.</p>');if(r.answer_mode==='evidence_fallback'||r.answer_mode==='general_unavailable')checkLlmStatus()}catch(e){if(e.name==='AbortError')m.querySelector('p').textContent='Response stopped.';else m.querySelector('p').textContent='Query failed: '+e.message}finally{chatController=null;setChatBusy(false);$('#q').focus()}}
$('#q').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();ask()}})
async function loadChatHistory(){if(!current)return;let rows=await api(`/api/vaults/${current.id}/chat`);let box=$('#messages');box.innerHTML='';if(!rows.length){addMsg('ai','This is a separate chat for this vault. Ask about its preserved knowledge and HIVE MIND will cite the evidence it uses.');return}rows.forEach(x=>addMsg(x.role==='user'?'user':'ai',x.content))}
async function clearChat(){if(!current)return;if(!confirm('Clear your chat history for this vault? Documents and evidence will not be deleted.'))return;await api(`/api/vaults/${current.id}/chat`,{method:'DELETE'});await loadChatHistory();toast('Vault chat cleared')}
async function showSettings(){if(!current)return toast('Select a vault');let x=await api(`/api/vaults/${current.id}/settings`);$('#panelTitle').textContent=`Vault Settings — ${current.name}`;$('#panelBody').innerHTML=`<div class="settingsGrid"><div class="settingCard"><h3>Scanning & Ingestion</h3>${[['auto_index','Index new documents'],['ocr_enabled','OCR images/scanned files'],['transcribe_media','Transcribe audio/video'],['extract_archives','Extract archives'],['malware_scan','Malware scanning'],['auto_categorize','Auto-categorize']].map(([k,n])=>`<label>${n}<input type="checkbox" id="vs_${k}" ${x[k]?'checked':''}></label>`).join('')}</div><div class="settingCard"><h3>Indexing</h3><label>Chunk size (characters)</label><input id="vs_chunk_chars" type="number" min="400" max="8000" value="${x.chunk_chars}"><h3>Allowed File Types</h3><textarea id="vs_allowed_extensions" rows="9">${esc(x.allowed_extensions)}</textarea><p class="muted">Scripts are indexed as text only and are never executed. Macro-enabled Office files are never allowed to run macros.</p></div></div>${(current.permissions.manage||me.role==='admin')?'<button class="primary" data-action="save-settings">Save Vault Settings</button>':'<p class="muted">Read-only: manage permission is required to change these settings.</p>'}${(current.permissions.manage||me.role==='admin')?`<div class="vault-danger-zone"><h3>Danger Zone</h3><p class="muted">Archive hides this vault from normal use without deleting its knowledge. Permanent deletion removes the vault, documents, index chunks, chat history, access rules, and vault settings.</p><div class="system-actions"><button class="danger-outline" data-action="archive-vault">Archive Vault</button><button class="danger" data-action="delete-vault">Permanently Delete Vault</button></div></div>`:''}`;openPanel('settings')}
async function saveSettings(){let p={};['auto_index','ocr_enabled','transcribe_media','extract_archives','malware_scan','auto_categorize'].forEach(k=>p[k]=$(`#vs_${k}`).checked);p.chunk_chars=+$('#vs_chunk_chars').value;p.allowed_extensions=$('#vs_allowed_extensions').value;await api(`/api/vaults/${current.id}/settings`,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(p)});toast('Vault settings saved');showSettings()}
function closePanel(){$('#panel').classList.add('hidden');if(current)setWorkspaceMode('chat')}
async function showUsers(){if(me.role!=='admin')return toast('Administrator role required');let us=await api('/api/users');$('#panelTitle').textContent='User Administration';$('#panelBody').innerHTML=`<button class="smallbtn" data-action="create-user">＋ Create User</button><table><tr><th>User</th><th>Role</th><th>Status</th><th>Actions</th></tr>${us.map(u=>`<tr><td><b>${esc(u.display_name)}</b><small>${esc(u.username)}</small></td><td>${esc(u.role)}</td><td>${u.deleted?'deleted':u.active?'active':'disabled'}</td><td>${u.deleted?'':`<button class="smallbtn" data-action="edit-user" data-id="${u.id}">Edit</button> ${u.id!==me.id?`<button class="danger" data-action="delete-user" data-id="${u.id}">Delete</button>`:''}`}</td></tr>`).join('')}</table>`;openPanel('panel')}
async function createUser(){let username=prompt('Username');if(!username)return;let display_name=prompt('Display name')||username;let role=prompt('Role: admin, knowledge_admin, hr, manager, auditor, user','user')||'user';let password=prompt('Temporary password (14+ chars, upper/lower/number/symbol)');if(!password)return;await api('/api/users',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,display_name,role,password,active:true})});showUsers();toast('User created')}
async function editUser(id){let us=await api('/api/users');let u=us.find(x=>x.id===id);let display_name=prompt('Display name',u.display_name);if(display_name===null)return;let role=prompt('Role',u.role);if(role===null)return;let a=confirm('Keep this account active?');let password=prompt('New temporary password (leave blank to keep current)')||null;await api(`/api/users/${id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({display_name,role,active:a,password})});showUsers();toast('User updated')}
async function deleteUser(id){if(!confirm('Delete/deactivate this user? Audit history will be retained.'))return;await api(`/api/users/${id}`,{method:'DELETE'});showUsers();toast('User deleted')}
async function showAudit(){if(!['admin','auditor'].includes(me.role))return toast('Auditor or admin role required');let a=await api('/api/audit');$('#panelTitle').textContent='Tamper-evident Audit Log';$('#panelBody').innerHTML=`<div class="audit-toolbar"><button class="smallbtn" data-action="export-audit-csv">Export CSV</button><button class="smallbtn" data-action="export-audit-txt">Export TXT</button><span class="muted">Exports include full hashes, IP addresses, vault IDs, and event details.</span></div><table><tr><th>Time</th><th>User</th><th>Action</th><th>Detail</th><th>Hash</th></tr>${a.map(x=>`<tr><td>${esc(x.time)}</td><td>${esc(x.user)}</td><td>${esc(x.action)}</td><td>${esc(x.detail)}</td><td>${esc(x.hash)}</td></tr>`).join('')}</table>`;openPanel('panel')}

async function showSystem(){if(me.role!=='admin')return toast('Administrator role required');let [status,cfg]=await Promise.all([api('/api/system/status'),api('/api/system/settings')]);$('#panelTitle').textContent='System & Security';$('#panelBody').innerHTML=`<h3>System Health</h3><div class="grid">${Object.entries(status).map(([k,v])=>`<div class="stat"><b>${esc(k)}</b><p>${esc(v)}</p></div>`).join('')}</div><h3>Editable System Settings</h3><p class="muted">These values are saved in the HIVE MIND database and survive upgrades. Changes to upload limits, scanning, and local AI apply immediately. Session and cookie changes affect new logins.</p><div class="settingsGrid systemSettingsGrid"><div class="settingCard"><h3>Limits & Sessions</h3><label>Session lifetime (hours)<input id="ss_session_hours" type="number" min="1" max="168" value="${cfg.session_hours}"></label><label>Maximum file size (MB)<input id="ss_max_upload_mb" type="number" min="1" max="102400" value="${cfg.max_upload_mb}"></label><label>Files per upload<input id="ss_max_files_per_upload" type="number" min="1" max="500" value="${cfg.max_files_per_upload}"></label><label>Maximum extracted text (characters)<input id="ss_max_text_chars" type="number" min="100000" max="100000000" value="${cfg.max_text_chars}"></label></div><div class="settingCard"><h3>Local AI</h3><label>Enable local LLM<input id="ss_enable_llm" type="checkbox" ${cfg.enable_llm?'checked':''}></label><label>Model<input id="ss_local_llm_model" value="${esc(cfg.local_llm_model)}"></label><label>Local LLM URL<input id="ss_local_llm_url" value="${esc(cfg.local_llm_url)}"></label><p class="muted">For security, HIVE MIND only accepts 127.0.0.1, localhost, or ::1 for the LLM endpoint.</p></div><div class="settingCard"><h3>Malware Scanning</h3><label>Require malware scanner<input id="ss_require_malware_scanner" type="checkbox" ${cfg.require_malware_scanner?'checked':''}></label><label>ClamAV executable path<input id="ss_clamav_path" value="${esc(cfg.clamav_path||'')}" placeholder="C:\\Program Files\\ClamAV\\clamscan.exe"></label><p class="muted">If required, uploads are rejected when the scanner is unavailable.</p></div><div class="settingCard"><h3>Web Session Security</h3><label>Secure cookies (HTTPS only)<input id="ss_cookie_secure" type="checkbox" ${cfg.cookie_secure?'checked':''}></label><p class="muted warningText">Leave Secure Cookies OFF while using HIVE MIND at http://127.0.0.1. Enable it only after HTTPS is configured, or browser logins will stop working.</p></div></div><div class="system-actions"><button class="primary" data-action="save-system-settings">Save System Settings</button><button class="smallbtn" data-action="show-system">Reload Values</button></div><h3>Backup & Restore</h3><p class="muted">Backups are encrypted with your passphrase. Restore is staged safely and applied the next time HIVE MIND starts.</p><div class="system-actions"><button class="smallbtn" data-action="make-backup">Create Backup</button><label class="smallbtn">Restore Backup<input id="restoreFileInput" type="file" accept=".nxb" hidden></label></div><div class="restore-note"><b>Restore safety:</b> HIVE MIND validates and stages the backup first. Your current database is safety-copied before the staged restore is applied on restart.</div>`;openPanel('panel');setTimeout(()=>{let f=$('#restoreFileInput');if(f)f.addEventListener('change',prepareRestore)},0)}
async function saveSystemSettings(){let p={session_hours:+$('#ss_session_hours').value,max_upload_mb:+$('#ss_max_upload_mb').value,max_files_per_upload:+$('#ss_max_files_per_upload').value,max_text_chars:+$('#ss_max_text_chars').value,enable_llm:$('#ss_enable_llm').checked,local_llm_model:$('#ss_local_llm_model').value.trim(),local_llm_url:$('#ss_local_llm_url').value.trim(),require_malware_scanner:$('#ss_require_malware_scanner').checked,clamav_path:$('#ss_clamav_path').value.trim(),cookie_secure:$('#ss_cookie_secure').checked};if(p.cookie_secure&&!confirm('Secure Cookies requires HTTPS. If HIVE MIND is still running at http://127.0.0.1, enabling this can prevent your next login. Save anyway?'))return;let r=await api('/api/system/settings',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(p)});toast(r.changed.length?`Saved: ${r.changed.join(', ')}`:'No system settings changed');checkLlmStatus();showSystem()}
async function makeBackup(){let passphrase=prompt('Backup passphrase (16+ characters). Store it securely; it is not recoverable.');if(!passphrase)return;let r=await api('/api/system/backup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({passphrase})});toast('Backup created: '+r.file);showSystem()}
async function prepareRestore(e){let file=e.target.files&&e.target.files[0];e.target.value='';if(!file)return;let passphrase=prompt('Enter the backup passphrase.');if(!passphrase)return;if(!confirm('Stage this backup for restore? The restore will be applied after you close and reopen HIVE MIND.'))return;let fd=new FormData();fd.append('backup',file);fd.append('passphrase',passphrase);try{let r=await api('/api/system/restore/prepare',{method:'POST',body:fd});alert('Restore validated and staged successfully.\n\nClose HIVE MIND and start it again to apply the restore.\n\nA safety copy of the current data will be created automatically.');toast('Restore staged — restart HIVE MIND')}catch(err){alert('Restore failed validation: '+err.message)}}
async function archiveVault(){
  if(!current||!current.permissions.manage)return toast('Vault manage permission required');
  if(!confirm(`Archive "${current.name}"?\n\nThe vault will disappear from normal use, but its encrypted documents and knowledge will be preserved.`))return;
  await api(`/api/vaults/${current.id}/archive`,{method:'POST'});
  toast('Vault archived'); current=null; await loadVaults(); $('#workspace').classList.add('hidden'); $('#panel').classList.add('hidden'); $('#empty').classList.remove('hidden')
}
async function deleteVault(id=null,name=null){
  const vid=id||(current&&current.id), vname=name||(current&&current.name);
  if(!vid||!vname)return toast('Select a vault');
  const typed=prompt(`PERMANENT DELETE\n\nThis removes the vault and all of its stored documents, index chunks, chat history, access rules, and vault settings. Audit history is retained.\n\nType the exact vault name to continue:\n${vname}`);
  if(typed===null)return;
  if(typed!==vname)return alert('Vault name did not match. Nothing was deleted.');
  if(!confirm(`Final confirmation: permanently delete "${vname}"?\n\nThis cannot be undone except by restoring a backup.`))return;
  const r=await api(`/api/vaults/${vid}`,{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({confirm_name:typed})});
  toast(`Vault deleted · ${r.documents_deleted} document(s) removed`);
  if(current&&current.id===vid){current=null;$('#workspace').classList.add('hidden');$('#empty').classList.remove('hidden')}
  await loadVaults(); $('#panel').classList.add('hidden')
}
async function showArchivedVaults(){
  if(!['admin','knowledge_admin'].includes(me.role))return toast('Administrator or Knowledge Admin role required');
  const rows=await api('/api/vaults/archived');
  $('#panelTitle').textContent='Archived Vaults';
  $('#panelBody').innerHTML=rows.length?`<p class="muted">Archived vaults are preserved but hidden from normal HIVE MIND use. Restore returns a vault to the active list.</p><table><tr><th>Vault</th><th>Department</th><th>Documents</th><th>Actions</th></tr>${rows.map(v=>`<tr><td><b>${esc(v.name)}</b><small>${esc(v.title||'')}</small></td><td>${esc(v.department||'')}</td><td>${v.documents}</td><td><button class="smallbtn" data-action="restore-vault" data-id="${v.id}">Restore</button> <button class="danger" data-action="delete-archived-vault" data-id="${v.id}" data-name="${esc(v.name)}">Delete</button></td></tr>`).join('')}</table>`:'<p class="muted">No archived vaults.</p>';
  openPanel('panel')
}
async function restoreVault(id){
  await api(`/api/vaults/${id}/restore`,{method:'POST'}); toast('Vault restored'); await loadVaults(); return showArchivedVaults()
}
async function showAccess(){
  if(!current||!current.permissions.manage)return toast('Vault manage permission required');
  let rows=await api(`/api/vaults/${current.id}/access`),us=me.role==='admin'?await api('/api/users'):[];
  $('#panelTitle').textContent='Vault Access';
  $('#panelBody').innerHTML=`
    <p class="muted">Vault access is explicit for HR, managers, auditors, and standard users. Admin and Knowledge Admin retain global vault access. Vaults without Read permission are completely hidden from the user.</p>
    ${me.role==='admin'?`<div class="access-editor">
      <div class="access-user-row"><label for="accessUser">User</label><select id="accessUser">${us.filter(x=>!x.deleted).map(x=>`<option value="${x.id}">${esc(x.username)} · ${esc(x.role)}</option>`).join('')}</select></div>
      <div class="access-permissions">
        <label class="access-check"><input type="checkbox" id="ar" checked><span>Read</span></label>
        <label class="access-check"><input type="checkbox" id="au"><span>Upload</span></label>
        <label class="access-check"><input type="checkbox" id="am"><span>Manage</span></label>
        <label class="access-check"><input type="checkbox" id="ax"><span>Restricted</span></label>
      </div>
      <div class="access-save-row"><button class="primary access-save-btn" data-action="set-access">Save Access</button></div>
    </div>`:''}
    <div class="access-table-wrap"><table><tr><th>User</th><th>Read</th><th>Upload</th><th>Manage</th><th>Restricted</th></tr>${rows.map(x=>`<tr><td>${esc(x.username)}</td><td>${x.can_read?'✓':''}</td><td>${x.can_upload?'✓':''}</td><td>${x.can_manage?'✓':''}</td><td>${x.can_restricted?'✓':''}</td></tr>`).join('')}</table></div>`;
  openPanel('access')
}
async function setAccess(){let p={user_id:+$('#accessUser').value,can_read:$('#ar').checked,can_upload:$('#au').checked,can_manage:$('#am').checked,can_restricted:$('#ax').checked};await api(`/api/vaults/${current.id}/access`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(p)});showAccess();toast('Access updated')}
document.addEventListener('click',async e=>{
  const b=e.target.closest('[data-action]');
  if(!b)return;
  const a=b.dataset.action;
  try{
    if(a==='logout') return logout();
    if(a==='new-vault') return newVault();
    if(a==='show-users') return showUsers();
    if(a==='show-system') return showSystem();
    if(a==='show-audit') return showAudit();
    if(a==='show-archived-vaults') return showArchivedVaults();
    if(a==='load-docs') return showDocuments();
    if(a==='show-chat') {$('#panel').classList.add('hidden');setWorkspaceMode('chat');return loadChatHistory();}
    if(a==='show-settings') return showSettings();
    if(a==='save-settings') return saveSettings();
    if(a==='archive-vault') return archiveVault();
    if(a==='delete-vault') return deleteVault();
    if(a==='restore-vault') return restoreVault(Number(b.dataset.id));
    if(a==='delete-archived-vault') return deleteVault(Number(b.dataset.id),b.dataset.name);
    if(a==='clear-chat') return clearChat();
    if(a==='show-documents') return showDocuments();
    if(a==='show-access') return showAccess();
    if(a==='ask') return ask();
    if(a==='stop-chat') return stopChat();
    if(a==='close-panel') return closePanel();
    if(a==='select-vault') return selectVault(Number(b.dataset.id));
    if(a==='delete-doc') return deleteDoc(Number(b.dataset.id));
    if(a==='select-all-docs') return selectAllDocuments(true);
    if(a==='select-none-docs') return selectAllDocuments(false);
    if(a==='delete-selected-docs') return bulkDeleteDocuments(false);
    if(a==='delete-all-docs') return bulkDeleteDocuments(true);
    if(a==='create-user') return createUser();
    if(a==='edit-user') return editUser(Number(b.dataset.id));
    if(a==='delete-user') return deleteUser(Number(b.dataset.id));
    if(a==='make-backup') return makeBackup();
    if(a==='save-system-settings') return saveSystemSettings();
    if(a==='export-audit-csv') return downloadAudit('csv');
    if(a==='export-audit-txt') return downloadAudit('txt');
    if(a==='set-access') return setAccess();
  }catch(err){toast(err.message||'Action failed')}
});

init();

function setChatMode(mode){
  if(!['auto','vault','general'].includes(mode))return; chatMode=mode;
  document.querySelectorAll('[data-chat-mode]').forEach(b=>b.classList.toggle('active',b.dataset.chatMode===mode));
  const hints={auto:'Auto uses vault evidence when relevant, otherwise normal local AI.',vault:'Vault Only answers from authorized vault evidence and cites its sources.',general:'General Chat uses local AI only. Vault records are not sent to the model.'};
  const h=$('#modeHint');if(h)h.textContent=hints[mode];
  const q=$('#q');if(q)q.placeholder=mode==='general'?'Ask HIVE MIND anything...':mode==='vault'?'Ask about this vault...':'Ask about the vault or anything else...';
}
document.addEventListener('click',e=>{const b=e.target.closest('[data-chat-mode]');if(b)setChatMode(b.dataset.chatMode)});
