import sys, importlib
mods=['fastapi','uvicorn','sqlalchemy','cryptography','argon2','fitz','docx','openpyxl','pptx','bs4','numpy','httpx','extract_msg']
failed=[]
for m in mods:
    try: importlib.import_module(m)
    except Exception as e: failed.append(f'{m}: {e}')
if sys.platform=='win32':
    try: importlib.import_module('pypff')
    except Exception as e: failed.append(f'pypff: {e}')
if failed:
    print('HIVE MIND dependency self-check FAILED:')
    print('\n'.join(' - '+x for x in failed))
    raise SystemExit(1)
print('HIVE MIND dependency self-check PASSED')
