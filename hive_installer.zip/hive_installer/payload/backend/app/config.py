from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "HIVE MIND"
    data_dir: Path = Path("./storage")
    db_url: str = ""
    host: str = "127.0.0.1"
    port: int = 8787
    allowed_hosts: str = "127.0.0.1,localhost"
    session_hours: int = 8
    max_upload_mb: int = 20480
    max_files_per_upload: int = 50
    max_text_chars: int = 20_000_000
    local_llm_url: str = "http://127.0.0.1:11434/api/chat"
    local_llm_model: str = "llama3.2:3b"
    enable_llm: bool = True
    require_malware_scanner: bool = False
    clamav_path: str = ""
    allow_remote_bootstrap: bool = False
    cookie_secure: bool = False
    model_config = SettingsConfigDict(env_file=".env", env_prefix="HIVE_", extra="ignore")

settings = Settings()
if not settings.db_url:
    settings.db_url = 'sqlite:///' + str((settings.data_dir/'nexus.db').resolve()).replace('\\','/')
for d in [settings.data_dir, settings.data_dir/'originals', settings.data_dir/'quarantine', settings.data_dir/'keys', settings.data_dir/'backups']:
    d.mkdir(parents=True, exist_ok=True)
