import hmac,hashlib
from datetime import datetime
from sqlalchemy.orm import Session
from app.db.models import AuditEvent
from app.security.crypto import master_key

def _digest(prev,created,username,action,vault_id,detail,ip):
    payload=f'{prev}|{created.isoformat()}|{username}|{action}|{vault_id}|{detail}|{ip}'.encode()
    return hmac.new(master_key(),payload,hashlib.sha256).hexdigest()

def audit(db:Session,action:str,detail:str='',vault_id=None,user=None,ip=''):
    prev=db.query(AuditEvent).order_by(AuditEvent.id.desc()).first();prev_hash=prev.event_hash if prev else '';username=getattr(user,'username','system');user_id=getattr(user,'id',None);created=datetime.utcnow();detail=detail[:4000]
    h=_digest(prev_hash,created,username,action,vault_id,detail,ip);row=AuditEvent(created_at=created,user_id=user_id,username=username,action=action,vault_id=vault_id,detail=detail,ip=ip,prev_hash=prev_hash,event_hash=h);db.add(row);db.commit();return row

def verify_chain(db:Session):
    prev=''
    for r in db.query(AuditEvent).order_by(AuditEvent.id.asc()):
        h=_digest(prev,r.created_at,r.username,r.action,r.vault_id,r.detail,r.ip)
        if r.prev_hash!=prev or not hmac.compare_digest(r.event_hash,h):return False,r.id
        prev=r.event_hash
    return True,None
