import io,tarfile,os,sqlite3,tempfile,shutil
from pathlib import Path
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from app.config import settings
from app.security.crypto import export_master_key, import_master_key

_CHUNK=4*1024*1024

def _key(passphrase,salt): return Scrypt(salt=salt,length=32,n=2**15,r=8,p=1).derive(passphrase.encode())

def _encrypt_stream(src:Path,dst:Path,key:bytes,aad:bytes,salt:bytes):
    nonce=os.urandom(12)
    enc=Cipher(algorithms.AES(key),modes.GCM(nonce)).encryptor();enc.authenticate_additional_data(aad)
    with src.open('rb') as fin,dst.open('wb') as fout:
        fout.write(b'NXB2'+salt+nonce)
        for block in iter(lambda:fin.read(_CHUNK),b''):
            out=enc.update(block)
            if out:fout.write(out)
        tail=enc.finalize()
        if tail:fout.write(tail)
        fout.write(enc.tag)

def _decrypt_stream(src:Path,dst:Path,passphrase:str):
    total=src.stat().st_size
    with src.open('rb') as fin:
        magic=fin.read(4)
        if magic==b'NXB1':
            # Backward compatibility with older, small backups.
            raw=magic+fin.read();salt=raw[4:20];nonce=raw[20:32]
            plain=AESGCM(_key(passphrase,salt)).decrypt(nonce,raw[32:],b'NEXUS-BACKUP')
            dst.write_bytes(plain);return
        if magic!=b'NXB2':raise ValueError('Not a NEXUS backup')
        salt=fin.read(16);nonce=fin.read(12)
        if len(salt)!=16 or len(nonce)!=12:raise ValueError('Corrupt NEXUS backup header')
        cipher_len=total-4-16-12-16
        if cipher_len<0:raise ValueError('Corrupt NEXUS backup')
        fin.seek(total-16);tag=fin.read(16);fin.seek(32)
        dec=Cipher(algorithms.AES(_key(passphrase,salt)),modes.GCM(nonce,tag)).decryptor();dec.authenticate_additional_data(b'NEXUS-BACKUP')
        remaining=cipher_len
        with dst.open('wb') as fout:
            while remaining:
                block=fin.read(min(_CHUNK,remaining))
                if not block:raise ValueError('Corrupt NEXUS backup: truncated ciphertext')
                remaining-=len(block);out=dec.update(block)
                if out:fout.write(out)
            tail=dec.finalize()
            if tail:fout.write(tail)

def create_backup(passphrase:str)->Path:
    if len(passphrase)<16: raise ValueError('Backup passphrase must be at least 16 characters')
    stamp=__import__('datetime').datetime.now().strftime('%Y%m%d-%H%M%S');out=settings.data_dir/'backups'/f'nexus-{stamp}.nxb';out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        root=Path(td);snapshot=root/'nexus.db';archive=root/'backup.tar.gz';src=settings.data_dir/'nexus.db'
        if src.exists():
            a=sqlite3.connect(src);b=sqlite3.connect(snapshot)
            try:a.backup(b)
            finally:b.close();a.close()
        keyfile=root/'master.key.raw';keyfile.write_bytes(export_master_key())
        with tarfile.open(archive,mode='w:gz') as tar:
            if snapshot.exists():tar.add(snapshot,arcname='nexus.db')
            if (settings.data_dir/'originals').exists():tar.add(settings.data_dir/'originals',arcname='originals',recursive=True)
            tar.add(keyfile,arcname='master.key.raw')
        salt=os.urandom(16);_encrypt_stream(archive,out,_key(passphrase,salt),b'NEXUS-BACKUP',salt)
    return out

def restore_backup(path:Path,passphrase:str):
    path=Path(path)
    with tempfile.TemporaryDirectory() as td:
        root=Path(td);archive=root/'backup.tar.gz';_decrypt_stream(path,archive,passphrase)
        with tarfile.open(archive,mode='r:gz') as tar:
            for m in tar.getmembers():
                dest=(root/m.name).resolve()
                if root.resolve() not in dest.parents and dest!=root.resolve():raise ValueError('Unsafe backup archive')
            tar.extractall(root)
        if not (root/'nexus.db').exists() or not (root/'master.key.raw').exists():raise ValueError('Backup is incomplete')
        safety=settings.data_dir/'backups'/('pre-restore-'+__import__('datetime').datetime.now().strftime('%Y%m%d-%H%M%S'))
        safety.mkdir(parents=True,exist_ok=True)
        if (settings.data_dir/'nexus.db').exists():shutil.copy2(settings.data_dir/'nexus.db',safety/'nexus.db')
        if (settings.data_dir/'originals').exists():shutil.copytree(settings.data_dir/'originals',safety/'originals',dirs_exist_ok=True)
        shutil.copy2(root/'nexus.db',settings.data_dir/'nexus.db')
        shutil.rmtree(settings.data_dir/'originals',ignore_errors=True)
        if (root/'originals').exists():shutil.copytree(root/'originals',settings.data_dir/'originals')
        else:(settings.data_dir/'originals').mkdir(parents=True,exist_ok=True)
        import_master_key((root/'master.key.raw').read_bytes())


def prepare_restore(path:Path,passphrase:str)->dict:
    """Validate/decrypt a backup into a staging directory. Does not touch live data."""
    path=Path(path)
    pending=settings.data_dir/'restore_pending'
    shutil.rmtree(pending,ignore_errors=True)
    pending.mkdir(parents=True,exist_ok=True)
    archive=pending/'backup.tar.gz'
    try:
        _decrypt_stream(path,archive,passphrase)
        with tarfile.open(archive,mode='r:gz') as tar:
            root=pending.resolve()
            for m in tar.getmembers():
                dest=(pending/m.name).resolve()
                if root not in dest.parents and dest!=root:
                    raise ValueError('Unsafe backup archive')
                if m.issym() or m.islnk():
                    raise ValueError('Backup contains unsupported links')
            tar.extractall(pending)
        archive.unlink(missing_ok=True)
        if not (pending/'nexus.db').exists() or not (pending/'master.key.raw').exists():
            raise ValueError('Backup is incomplete')
        # Verify SQLite snapshot before marking it pending.
        con=sqlite3.connect(pending/'nexus.db')
        try:
            row=con.execute('PRAGMA integrity_check').fetchone()
            if not row or row[0]!='ok': raise ValueError('Backup database integrity check failed')
        finally: con.close()
        (pending/'READY').write_text('HIVE MIND staged restore\n',encoding='utf-8')
        return {'ok':True,'restart_required':True}
    except Exception:
        shutil.rmtree(pending,ignore_errors=True)
        raise

def apply_pending_restore()->bool:
    """Apply a previously validated restore before the web server opens the database."""
    pending=settings.data_dir/'restore_pending'
    if not (pending/'READY').exists(): return False
    if not (pending/'nexus.db').exists() or not (pending/'master.key.raw').exists():
        shutil.rmtree(pending,ignore_errors=True); raise ValueError('Pending restore is incomplete')
    stamp=__import__('datetime').datetime.now().strftime('%Y%m%d-%H%M%S')
    safety=settings.data_dir/'backups'/('pre-restore-'+stamp)
    safety.mkdir(parents=True,exist_ok=True)
    live_db=settings.data_dir/'nexus.db'
    if live_db.exists(): shutil.copy2(live_db,safety/'nexus.db')
    live_orig=settings.data_dir/'originals'
    if live_orig.exists(): shutil.copytree(live_orig,safety/'originals',dirs_exist_ok=True)
    # Atomic-ish DB replacement while no SQLAlchemy engine has opened it.
    newdb=settings.data_dir/'nexus.db.restore-new'
    shutil.copy2(pending/'nexus.db',newdb)
    os.replace(newdb,live_db)
    shutil.rmtree(live_orig,ignore_errors=True)
    if (pending/'originals').exists(): shutil.copytree(pending/'originals',live_orig)
    else: live_orig.mkdir(parents=True,exist_ok=True)
    import_master_key((pending/'master.key.raw').read_bytes())
    shutil.rmtree(pending,ignore_errors=True)
    return True
