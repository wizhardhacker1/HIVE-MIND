from pathlib import Path
import hashlib,tempfile,shutil,time,gc,atexit
from fastapi import UploadFile,HTTPException
from sqlalchemy.orm import Session
from app.config import settings
from app.db.models import Document,Chunk
from app.ingestion.parsers import parse_file
from app.rag.engine import chunk_text,embed,enc_text
from app.security.crypto import store_original
from app.security.guards import validate_filename
from app.security.scanner import malware_scan,redact_and_classify



_PENDING_TEMP_CLEANUP = set()

def _cleanup_temp_path(path: Path, attempts: int = 8) -> bool:
    """Best-effort removal that tolerates delayed Windows native handles."""
    path = Path(path)
    if not path.exists():
        _PENDING_TEMP_CLEANUP.discard(str(path))
        return True
    for n in range(attempts):
        try:
            gc.collect()
            path.unlink(missing_ok=True)
            _PENDING_TEMP_CLEANUP.discard(str(path))
            return True
        except PermissionError:
            # libpff/AV scanners can release handles a few hundred ms later.
            time.sleep(min(0.10 * (n + 1), 0.75))
        except FileNotFoundError:
            _PENDING_TEMP_CLEANUP.discard(str(path))
            return True
        except OSError:
            time.sleep(min(0.10 * (n + 1), 0.75))
    _PENDING_TEMP_CLEANUP.add(str(path))
    return False

def _cleanup_pending_temp_files():
    for raw in list(_PENDING_TEMP_CLEANUP):
        _cleanup_temp_path(Path(raw), attempts=2)

atexit.register(_cleanup_pending_temp_files)

def sha256_file(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

async def ingest_upload(db:Session,vault_id:int,upload:UploadFile):
    safe=validate_filename(upload.filename or 'upload.bin'); maxb=settings.max_upload_mb*1024*1024; total=0
    with tempfile.NamedTemporaryFile(delete=False,suffix=Path(safe).suffix) as tmp:
        while True:
            b=await upload.read(1024*1024)
            if not b:break
            total+=len(b)
            if total>maxb:
                _cleanup_temp_path(Path(tmp.name)); raise HTTPException(413,f'{safe} exceeds {settings.max_upload_mb} MB limit')
            tmp.write(b)
        p=Path(tmp.name)
    try:
        scan=malware_scan(p)
        if scan in {'infected','scanner_required','scan_error'}:
            q=settings.data_dir/'quarantine'/(sha256_file(p)[:12]+'_'+safe); shutil.move(str(p),q); raise HTTPException(422,f'Upload quarantined: malware status={scan}')
        digest=sha256_file(p); existing=db.query(Document).filter_by(vault_id=vault_id,sha256=digest).first()
        if existing:return existing,0,True,[]
        text,stype=parse_file(p); text,sens,flags=redact_and_classify(text)
        target=settings.data_dir/'originals'/str(vault_id)/(digest[:12]+'_'+safe); stored=store_original(p,target)
        doc=Document(vault_id=vault_id,filename=safe,source_type=stype,mime_type=upload.content_type,source_path=str(stored),sha256=digest,size_bytes=total,sensitivity=sens,malware_status=scan); db.add(doc); db.flush(); count=0
        for pos,ch in enumerate(chunk_text(text)):
            db.add(Chunk(document_id=doc.id,position=pos,text_enc=enc_text(ch),embedding_enc=embed(ch)));count+=1
        db.commit();db.refresh(doc);return doc,count,False,flags
    finally:
        # Cleanup must never turn a successful import into a WinError 32.
        # Native PST readers and endpoint-security scanners can release the
        # temp-file handle asynchronously on Windows, so defer if necessary.
        _cleanup_temp_path(p)
