from pathlib import Path
import csv,json,email
from bs4 import BeautifulSoup

def parse_txt(p): return p.read_text(errors='replace')
def parse_json(p): return json.dumps(json.loads(p.read_text(errors='replace')),ensure_ascii=False,indent=2)
def parse_csv(p):
    out=[]
    with p.open(errors='replace',newline='') as f:
        for i,row in enumerate(csv.reader(f)):
            if i>250000: break
            out.append(' | '.join(row))
    return '\n'.join(out)
def parse_html(p): return BeautifulSoup(p.read_text(errors='replace'),'html.parser').get_text('\n')
def parse_docx(p):
    from docx import Document
    d=Document(p); out=[x.text for x in d.paragraphs if x.text.strip()]
    for t in d.tables:
        for row in t.rows: out.append(' | '.join(c.text for c in row.cells))
    return '\n'.join(out)
def parse_xlsx(p):
    import openpyxl
    wb=openpyxl.load_workbook(p,read_only=True,data_only=False,keep_links=False); out=[]
    for ws in wb.worksheets:
        out.append(f'# Sheet: {ws.title}')
        for idx,row in enumerate(ws.iter_rows(values_only=False)):
            if idx>100000: break
            vals=[f'{c.coordinate}={c.value}' for c in row if c.value is not None]
            if vals:out.append(' | '.join(vals))
    return '\n'.join(out)
def parse_pptx(p):
    from pptx import Presentation
    prs=Presentation(p); out=[]
    for i,s in enumerate(prs.slides,1):
        out.append(f'# Slide {i}')
        for sh in s.shapes:
            if hasattr(sh,'text') and sh.text.strip():out.append(sh.text)
    return '\n'.join(out)
def parse_pdf(p):
    import fitz
    doc=fitz.open(p); return '\n'.join(f'# Page {i+1}\n{pg.get_text()}' for i,pg in enumerate(doc))
def parse_eml(p):
    with p.open('rb') as f: msg=email.message_from_binary_file(f)
    out=[f"From: {msg.get('From','')}",f"To: {msg.get('To','')}",f"Cc: {msg.get('Cc','')}",f"Date: {msg.get('Date','')}",f"Subject: {msg.get('Subject','')}"]
    for part in msg.walk() if msg.is_multipart() else [msg]:
        if part.get_content_type() in {'text/plain','text/html'} and not part.get_filename():
            b=part.get_payload(decode=True)
            if b:
                s=b.decode(part.get_content_charset() or 'utf-8',errors='replace'); out.append(BeautifulSoup(s,'html.parser').get_text('\n') if part.get_content_type()=='text/html' else s)
    return '\n'.join(out)

def parse_msg(p):
    try:
        import extract_msg
    except Exception as e:
        raise RuntimeError('MSG support is not installed correctly. Run Repair NEXUS.') from e
    msg = extract_msg.Message(str(p))
    try:
        out=[
            f"From: {getattr(msg,'sender','') or ''}",
            f"To: {getattr(msg,'to','') or ''}",
            f"Cc: {getattr(msg,'cc','') or ''}",
            f"Date: {getattr(msg,'date','') or ''}",
            f"Subject: {getattr(msg,'subject','') or ''}",
            getattr(msg,'body','') or '',
        ]
        return '\n'.join(str(x) for x in out if x is not None)
    finally:
        try: msg.close()
        except Exception: pass

def parse_pst(p):
    # pypff/libpff is a native library. On Windows its child objects can keep
    # the PST handle alive until those Python wrappers are collected, so keep
    # object lifetimes short and always close the native file in a finally.
    try:
        import pypff
    except Exception as e:
        raise RuntimeError('PST support requires locally installed pypff/libpff.') from e

    import gc
    pst = pypff.file()
    out = []
    try:
        pst.open(str(p))

        def walk(folder):
            try:
                message_count = folder.number_of_sub_messages
                for i in range(message_count):
                    m = folder.get_sub_message(i)
                    try:
                        out.append(
                            f"From: {getattr(m,'sender_name','')}\n"
                            f"Subject: {getattr(m,'subject','')}\n"
                            f"{getattr(m,'plain_text_body','') or ''}"
                        )
                    finally:
                        # Drop native message wrappers as soon as possible.
                        del m

                folder_count = folder.number_of_sub_folders
                for i in range(folder_count):
                    child = folder.get_sub_folder(i)
                    try:
                        walk(child)
                    finally:
                        del child
            finally:
                # The caller owns the folder wrapper; collection is forced
                # after the top-level walk returns.
                pass

        root = pst.get_root_folder()
        try:
            walk(root)
        finally:
            del root
    finally:
        try:
            pst.close()
        finally:
            del pst
            gc.collect()

    return '\n\n'.join(out)
def transcribe_media(p):
    try: from faster_whisper import WhisperModel
    except Exception as e: raise RuntimeError('Media transcription requires a locally installed faster-whisper model and FFmpeg.') from e
    model=WhisperModel('small',device='cpu',compute_type='int8',local_files_only=True); seg,_=model.transcribe(str(p)); return '\n'.join(f'[{s.start:.1f}-{s.end:.1f}] {s.text.strip()}' for s in seg)

def parse_zip(p):
    import zipfile,tempfile
    out=[]; total=0
    with zipfile.ZipFile(p) as z:
        infos=z.infolist()
        if len(infos)>5000: raise RuntimeError('Archive contains too many files')
        for info in infos:
            if info.is_dir(): continue
            total+=info.file_size
            if total>500*1024*1024: raise RuntimeError('Archive uncompressed size exceeds 500 MB')
            name=Path(info.filename)
            if name.is_absolute() or '..' in name.parts: raise RuntimeError('Unsafe archive path detected')
            ext=name.suffix.lower()
            if ext in {'.zip','.exe','.dll','.com','.scr','.msi','.bat','.cmd','.js','.vbs','.jar','.lnk'}: continue
            try:
                data=z.read(info)
                with tempfile.NamedTemporaryFile(delete=False,suffix=ext) as tf: tf.write(data); tp=Path(tf.name)
                try:
                    text,stype=parse_file(tp); out.append(f'# ARCHIVE MEMBER: {info.filename} ({stype})\n{text}')
                finally: tp.unlink(missing_ok=True)
            except Exception:
                continue
    return '\n\n'.join(out)


def parse_rtf(p):
    try:
        from striprtf.striprtf import rtf_to_text
        return rtf_to_text(p.read_text(errors='replace'))
    except Exception: return p.read_text(errors='replace')
def parse_xml(p): return BeautifulSoup(p.read_text(errors='replace'),'xml').get_text('\n')
def parse_image_ocr(p):
    try:
        import pytesseract
        from PIL import Image
        return pytesseract.image_to_string(Image.open(p))
    except Exception as e: raise RuntimeError('Image OCR requires the local Tesseract OCR engine. Enable/install it in HIVE MIND Settings.') from e
def parse_xls(p):
    import xlrd
    wb=xlrd.open_workbook(str(p),on_demand=True); out=[]
    for ws in wb.sheets():
        out.append(f'# Sheet: {ws.name}')
        for r in range(min(ws.nrows,100000)):
            vals=[str(ws.cell_value(r,c)) for c in range(ws.ncols) if ws.cell_value(r,c) not in ('',None)]
            if vals: out.append(' | '.join(vals))
    return '\n'.join(out)
def parse_legacy_office(p,kind):
    import os
    if os.name!='nt': raise RuntimeError(f'Legacy {kind} extraction requires Microsoft Office on Windows.')
    try:
        import win32com.client
        if kind=='word':
            app=win32com.client.DispatchEx('Word.Application'); app.Visible=False
            try:
                doc=app.Documents.Open(str(p),ReadOnly=True); text=doc.Content.Text; doc.Close(False); return text
            finally: app.Quit()
        app=win32com.client.DispatchEx('PowerPoint.Application')
        try:
            pres=app.Presentations.Open(str(p),WithWindow=False); out=[]
            for slide in pres.Slides:
                for shape in slide.Shapes:
                    try:
                        if shape.HasTextFrame and shape.TextFrame.HasText: out.append(shape.TextFrame.TextRange.Text)
                    except Exception: pass
            pres.Close(); return '\n'.join(out)
        finally: app.Quit()
    except Exception as e: raise RuntimeError(f'Legacy {kind} file requires locally installed Microsoft Office for safe extraction.') from e

def parse_file(p):
    e=p.suffix.lower()
    if e in {'.txt','.md','.log','.ini','.cfg','.conf','.py','.ps1','.sh','.yaml','.yml','.bat','.cmd','.js','.ts','.sql','.toml','.properties'}:return parse_txt(p),'text'
    if e=='.rtf': return parse_rtf(p),'rtf'
    if e=='.xml': return parse_xml(p),'xml'
    if e in {'.png','.jpg','.jpeg','.tif','.tiff','.bmp','.webp'}: return parse_image_ocr(p),'image-ocr'
    if e=='.json':return parse_json(p),'json'
    if e in {'.csv','.tsv'}:return parse_csv(p),'csv'
    if e in {'.html','.htm'}:return parse_html(p),'html'
    if e in {'.docx','.dotx','.docm','.dotm'}:return parse_docx(p),'word'
    if e in {'.doc','.dot'}: return parse_legacy_office(p,'word'),'word-legacy'
    if e in {'.xlsx','.xlsm','.xltx','.xltm'}:return parse_xlsx(p),'excel'
    if e in {'.xls','.xlt'}: return parse_xls(p),'excel-legacy'
    if e in {'.pptx','.pptm','.ppsx','.potx'}:return parse_pptx(p),'powerpoint'
    if e in {'.ppt','.pps','.pot'}: return parse_legacy_office(p,'powerpoint'),'powerpoint-legacy'
    if e=='.pdf':return parse_pdf(p),'pdf'
    if e=='.eml':return parse_eml(p),'email'
    if e=='.pst':return parse_pst(p),'pst'
    if e=='.msg':return parse_msg(p),'email'
    if e=='.zip': return parse_zip(p),'archive'
    if e in {'.mp3','.wav','.m4a','.mp4','.mov','.avi','.mkv'}:return transcribe_media(p),'media'
    raise RuntimeError(f'Unsupported file type: {e}')
