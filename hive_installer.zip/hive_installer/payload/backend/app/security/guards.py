import time, threading, ipaddress, socket
from pathlib import Path
from fastapi import HTTPException, UploadFile
from app.config import settings

ALLOWED_EXT={'.txt','.md','.log','.ini','.cfg','.conf','.py','.ps1','.sh','.yaml','.yml','.json','.csv','.html','.htm','.docx','.xlsx','.xlsm','.pptx','.pdf','.eml','.pst','.msg','.mp3','.wav','.m4a','.mp4','.mov','.avi','.mkv','.zip'}
BLOCKED_EXT={'.exe','.dll','.com','.scr','.msi','.bat','.cmd','.js','.vbs','.jar','.lnk','.iso','.img','.ps1xml'}
_buckets={}; _lock=threading.Lock()
def rate_limit(key:str,limit:int,window:int=60):
    now=time.time()
    with _lock:
        arr=[t for t in _buckets.get(key,[]) if now-t<window]
        if len(arr)>=limit: raise HTTPException(429,'Too many requests')
        arr.append(now); _buckets[key]=arr

def validate_filename(name:str):
    n=Path(name or 'upload.bin').name
    ext=Path(n).suffix.lower()
    if ext in BLOCKED_EXT or ext not in ALLOWED_EXT: raise HTTPException(415,f'File type {ext or "unknown"} is not allowed')
    return n

def llm_url_is_safe(url:str)->bool:
    try:
        from urllib.parse import urlparse
        u=urlparse(url)
        if u.scheme not in {'http','https'} or not u.hostname: return False
        infos=socket.getaddrinfo(u.hostname,u.port or 80,type=socket.SOCK_STREAM)
        for info in infos:
            ip=ipaddress.ip_address(info[4][0])
            if not (ip.is_loopback or ip.is_private): return False
        return True
    except Exception: return False
