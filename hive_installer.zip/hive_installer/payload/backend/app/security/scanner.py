import re, subprocess
from pathlib import Path
from app.config import settings

PATTERNS=[
 ('private_key',re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')),
 ('aws_key',re.compile(r'\bAKIA[0-9A-Z]{16}\b')),
 ('generic_secret',re.compile(r'(?i)\b(password|passwd|api[_ -]?key|secret|token)\s*[:=]\s*["\']?([^\s"\']{8,})')),
 ('ssn',re.compile(r'\b\d{3}-\d{2}-\d{4}\b')),
]

def redact_and_classify(text:str):
    sensitivity='normal'; found=[]
    for label,pat in PATTERNS:
        if pat.search(text): sensitivity='restricted'; found.append(label); text=pat.sub(f'[REDACTED:{label}]',text)
    return text,sensitivity,sorted(set(found))

def malware_scan(path:Path):
    exe=settings.clamav_path.strip()
    if not exe:
        if settings.require_malware_scanner: return 'scanner_required'
        return 'not_scanned'
    try:
        r=subprocess.run([exe,'--no-summary',str(path)],capture_output=True,text=True,timeout=120)
        if r.returncode==0:return 'clean'
        if r.returncode==1:return 'infected'
        return 'scan_error'
    except Exception:return 'scan_error'
