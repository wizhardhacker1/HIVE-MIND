import os, ctypes, ctypes.wintypes
from pathlib import Path
from typing import Iterator
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from app.config import settings

_KEY_FILE=settings.data_dir/'keys'/'master.key'
_NMX2=b'NMX2'
_CHUNK=4*1024*1024

class DATA_BLOB(ctypes.Structure):
    _fields_=[('cbData',ctypes.wintypes.DWORD),('pbData',ctypes.POINTER(ctypes.c_char))]

def _dpapi(data: bytes, protect=True) -> bytes:
    if os.name!='nt': return data
    inbuf=ctypes.create_string_buffer(data); inp=DATA_BLOB(len(data),ctypes.cast(inbuf,ctypes.POINTER(ctypes.c_char))); out=DATA_BLOB()
    fn=ctypes.windll.crypt32.CryptProtectData if protect else ctypes.windll.crypt32.CryptUnprotectData
    if protect:
        ok=fn(ctypes.byref(inp),'NEXUS Memory Key',None,None,None,0x4,ctypes.byref(out))
    else:
        ok=fn(ctypes.byref(inp),None,None,None,None,0x4,ctypes.byref(out))
    if not ok: raise OSError('Windows DPAPI operation failed')
    try: return ctypes.string_at(out.pbData,out.cbData)
    finally: ctypes.windll.kernel32.LocalFree(out.pbData)

def master_key() -> bytes:
    _KEY_FILE.parent.mkdir(parents=True,exist_ok=True)
    if _KEY_FILE.exists(): return _dpapi(_KEY_FILE.read_bytes(),False)
    key=os.urandom(32); wrapped=_dpapi(key,True); _KEY_FILE.write_bytes(wrapped)
    try: os.chmod(_KEY_FILE,0o600)
    except OSError: pass
    return key

def encrypt_bytes(data: bytes, aad: bytes=b'') -> bytes:
    nonce=os.urandom(12); return nonce+AESGCM(master_key()).encrypt(nonce,data,aad)

def decrypt_bytes(blob: bytes, aad: bytes=b'') -> bytes:
    return AESGCM(master_key()).decrypt(blob[:12],blob[12:],aad)

def encrypt_file(src: Path, dst: Path, aad: bytes=b'original') -> Path:
    """Stream AES-256-GCM encryption; safe for multi-gigabyte files."""
    src=Path(src); dst=Path(dst); dst.parent.mkdir(parents=True,exist_ok=True)
    nonce=os.urandom(12)
    encryptor=Cipher(algorithms.AES(master_key()),modes.GCM(nonce)).encryptor()
    encryptor.authenticate_additional_data(aad)
    with src.open('rb') as fin, dst.open('wb') as fout:
        fout.write(_NMX2); fout.write(nonce)
        while True:
            block=fin.read(_CHUNK)
            if not block: break
            out=encryptor.update(block)
            if out: fout.write(out)
        tail=encryptor.finalize()
        if tail: fout.write(tail)
        fout.write(encryptor.tag)
    try: os.chmod(dst,0o600)
    except OSError: pass
    return dst

def decrypt_file_iter(path: Path, aad: bytes=b'original', chunk_size:int=_CHUNK) -> Iterator[bytes]:
    """Yield plaintext without materializing the complete original in memory."""
    path=Path(path)
    with path.open('rb') as fin:
        magic=fin.read(4)
        if magic!=_NMX2:
            # Backward compatibility with NMX1 originals. These were necessarily
            # below the old AESGCM single-buffer ceiling.
            fin.seek(0)
            blob=fin.read()
            plain=decrypt_bytes(blob,aad)
            for i in range(0,len(plain),chunk_size):
                yield plain[i:i+chunk_size]
            return
        nonce=fin.read(12)
        if len(nonce)!=12: raise ValueError('Corrupt encrypted original: missing nonce')
        total=path.stat().st_size
        cipher_len=total-4-12-16
        if cipher_len<0: raise ValueError('Corrupt encrypted original')
        fin.seek(total-16); tag=fin.read(16); fin.seek(16)
        decryptor=Cipher(algorithms.AES(master_key()),modes.GCM(nonce,tag)).decryptor()
        decryptor.authenticate_additional_data(aad)
        remaining=cipher_len
        while remaining:
            block=fin.read(min(chunk_size,remaining))
            if not block: raise ValueError('Corrupt encrypted original: truncated ciphertext')
            remaining-=len(block)
            out=decryptor.update(block)
            if out: yield out
        tail=decryptor.finalize()
        if tail: yield tail

def store_original(src: Path,dst: Path)->Path:
    out=Path(dst).with_suffix(Path(dst).suffix+'.nmx')
    return encrypt_file(Path(src),out,b'original')

def read_original(path: Path)->bytes:
    # Compatibility helper for callers that genuinely need a small original.
    return b''.join(decrypt_file_iter(path,b'original'))

def export_master_key()->bytes: return master_key()
def import_master_key(key:bytes):
    if len(key)!=32: raise ValueError('Invalid master key')
    _KEY_FILE.parent.mkdir(parents=True,exist_ok=True)
    _KEY_FILE.write_bytes(_dpapi(key,True))
    try: os.chmod(_KEY_FILE,0o600)
    except OSError: pass
