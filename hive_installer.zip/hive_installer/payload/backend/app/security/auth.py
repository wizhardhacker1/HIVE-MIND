import secrets, hashlib, hmac
from datetime import datetime, timedelta
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from fastapi import Depends, HTTPException, Request, Response
from sqlalchemy.orm import Session
from app.config import settings
from app.db.database import get_db
from app.db.models import User, SessionToken, VaultAccess
from app.security.crypto import master_key

ph=PasswordHasher(time_cost=3,memory_cost=65536,parallelism=2,hash_len=32,salt_len=16)
ROLES={'admin','knowledge_admin','hr','manager','auditor','user'}

def hash_token(s:str)->str: return hashlib.sha256(s.encode()).hexdigest()
def password_ok(p:str)->bool: return len(p)>=14 and any(c.islower() for c in p) and any(c.isupper() for c in p) and any(c.isdigit() for c in p) and any(not c.isalnum() for c in p)
def hash_password(p:str)->str: return ph.hash(p)
def verify_password(h:str,p:str)->bool:
    try: return ph.verify(h,p)
    except VerifyMismatchError: return False
    except Exception: return False

def csrf_for_session_cookie(session_cookie:str)->str:
    # Stable per-session CSRF token. This prevents another tab or a page refresh
    # from invalidating an already-open HIVE MIND session. The browser cannot
    # derive this value because the HMAC key is the DPAPI-protected master key.
    return hmac.new(master_key(),('csrf:'+session_cookie).encode('utf-8'),hashlib.sha256).hexdigest()

def create_session(db:Session,user:User,response:Response):
    token=secrets.token_urlsafe(48); csrf=csrf_for_session_cookie(token)
    db.add(SessionToken(user_id=user.id,token_hash=hash_token(token),csrf_hash=hash_token(csrf),expires_at=datetime.utcnow()+timedelta(hours=settings.session_hours))); db.commit()
    response.set_cookie('nexus_session',token,httponly=True,samesite='strict',secure=settings.cookie_secure,max_age=settings.session_hours*3600,path='/')
    return csrf

def current_user(request:Request,db:Session=Depends(get_db))->User:
    token=request.cookies.get('nexus_session')
    if not token: raise HTTPException(401,'Authentication required')
    s=db.query(SessionToken).filter(SessionToken.token_hash==hash_token(token),SessionToken.expires_at>datetime.utcnow()).first()
    if not s: raise HTTPException(401,'Session expired')
    u=db.get(User,s.user_id)
    if not u or not u.active or u.deleted: raise HTTPException(403,'Account disabled')
    if u.must_change_password and request.url.path not in {'/api/auth/me','/api/auth/change-password','/api/auth/logout'}: raise HTTPException(428,'Password change required')
    request.state.session=s; request.state.user=u; return u

def require_csrf(request:Request,user:User=Depends(current_user)):
    token=request.headers.get('X-CSRF-Token','')
    s=request.state.session
    session_cookie=request.cookies.get('nexus_session','')
    stable=csrf_for_session_cookie(session_cookie) if session_cookie else ''
    # Accept the stable token. Also accept the stored legacy token hash so users
    # with a session created by an older build are not forced to log in again.
    stable_ok=bool(token and stable and secrets.compare_digest(token,stable))
    legacy_ok=bool(token and secrets.compare_digest(hash_token(token),s.csrf_hash))
    if not (stable_ok or legacy_ok): raise HTTPException(403,'CSRF validation failed')
    return user

def rotate_csrf(db:Session,s:SessionToken)->str:
    # Retained only for source compatibility. New code returns the stable token
    # from the session cookie instead of rotating on /api/auth/me.
    token=secrets.token_urlsafe(32); s.csrf_hash=hash_token(token); db.commit(); return token

def role_required(*roles):
    def dep(user:User=Depends(current_user)):
        if user.role not in roles: raise HTTPException(403,'Insufficient role')
        return user
    return dep

def vault_permissions(db:Session,user:User,vault_id:int):
    # Global vault visibility is intentionally limited to system custodians.
    # HR, managers, auditors and standard users require an explicit VaultAccess row.
    # This is enforced server-side so hidden vaults cannot be reached by guessing IDs.
    if user.role in {'admin','knowledge_admin'}:
        return {'read':True,'upload':True,'manage':True,'restricted':user.role=='admin'}
    a=db.query(VaultAccess).filter_by(user_id=user.id,vault_id=vault_id).first()
    return {'read':bool(a and a.can_read),'upload':bool(a and a.can_upload),'manage':bool(a and a.can_manage),'restricted':bool(a and a.can_restricted)}
