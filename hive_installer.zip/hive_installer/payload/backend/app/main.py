from pathlib import Path
from datetime import datetime,timedelta
import secrets, json, csv, io
from fastapi import FastAPI,Depends,UploadFile,File,Form,HTTPException,Request,Response
from fastapi.responses import FileResponse,StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from pydantic import BaseModel,Field
from sqlalchemy.orm import Session
from app.config import settings
from app.db.database import Base,engine,get_db,SessionLocal
from app.db.models import User,SessionToken,Vault,VaultAccess,Document,Chunk,AuditEvent,VaultSetting,ChatMessage,SystemSetting
from app.security.auth import current_user,require_csrf,role_required,create_session,csrf_for_session_cookie,hash_password,verify_password,password_ok,ROLES,vault_permissions
from app.security.guards import rate_limit
from app.security.crypto import decrypt_file_iter,encrypt_bytes,decrypt_bytes
from app.services.ingest import ingest_upload
from app.services.audit import audit,verify_chain
from app.services.backup import create_backup,prepare_restore
from app.rag.engine import search,answer_with_local_llm,answer_general_chat,dec_text,local_llm_status

Base.metadata.create_all(bind=engine)
app=FastAPI(title='HIVE MIND',version='2.0.10',docs_url=None,redoc_url=None,openapi_url=None)
app.add_middleware(TrustedHostMiddleware,allowed_hosts=[x.strip() for x in settings.allowed_hosts.split(',') if x.strip()])
FRONTEND=Path(__file__).resolve().parents[2]/'frontend'; app.mount('/static',StaticFiles(directory=FRONTEND),name='static')

@app.middleware('http')
async def security_headers(request,call_next):
    r=await call_next(request)
    r.headers['X-Content-Type-Options']='nosniff'; r.headers['X-Frame-Options']='DENY'; r.headers['Referrer-Policy']='no-referrer'; r.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()'
    r.headers['Content-Security-Policy']="default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"
    r.headers['Cache-Control']='no-store'; return r

class SetupIn(BaseModel): username:str=Field(min_length=3,max_length=120); display_name:str=Field(min_length=1,max_length=200); password:str
class LoginIn(BaseModel): username:str; password:str
class UserIn(BaseModel): username:str=Field(min_length=3,max_length=120); display_name:str=Field(min_length=1,max_length=200); role:str='user'; password:str; active:bool=True
class UserPatch(BaseModel): display_name:str|None=None; role:str|None=None; active:bool|None=None; password:str|None=None
class VaultIn(BaseModel): name:str=Field(min_length=1,max_length=200); title:str|None=None; department:str|None=None
class VaultPatch(BaseModel): name:str|None=None; title:str|None=None; department:str|None=None; active:bool|None=None
class AccessIn(BaseModel): user_id:int; can_read:bool=True; can_upload:bool=False; can_manage:bool=False; can_restricted:bool=False
class ChatIn(BaseModel):
    vault_id:int
    question:str=Field(min_length=1,max_length=5000)
    mode:str=Field(default='auto',pattern='^(auto|vault|general)$')
class VaultSettingsIn(BaseModel):
    auto_index:bool=True; ocr_enabled:bool=True; transcribe_media:bool=False; extract_archives:bool=True
    malware_scan:bool=True; auto_categorize:bool=True; chunk_chars:int=Field(default=1200,ge=400,le=8000); allowed_extensions:str='' 
class BulkDeleteDocumentsIn(BaseModel):
    document_ids:list[int]=Field(default_factory=list,max_length=10000)
    delete_all:bool=False

class VaultDeleteIn(BaseModel):
    confirm_name:str=Field(min_length=1,max_length=200)

class BackupIn(BaseModel): passphrase:str=Field(min_length=16,max_length=500)
class ChangePasswordIn(BaseModel): current_password:str; new_password:str

class SystemSettingsIn(BaseModel):
    session_hours:int=Field(ge=1,le=168)
    max_upload_mb:int=Field(ge=1,le=102400)
    max_files_per_upload:int=Field(ge=1,le=500)
    max_text_chars:int=Field(ge=100000,le=100000000)
    enable_llm:bool=True
    local_llm_model:str=Field(min_length=1,max_length=120)
    local_llm_url:str=Field(min_length=1,max_length=500)
    require_malware_scanner:bool=False
    clamav_path:str=Field(default='',max_length=1000)
    cookie_secure:bool=False

SYSTEM_SETTING_KEYS={
    'session_hours','max_upload_mb','max_files_per_upload','max_text_chars','enable_llm',
    'local_llm_model','local_llm_url','require_malware_scanner','clamav_path','cookie_secure'
}

def _safe_local_llm_url(url:str)->bool:
    try:
        from urllib.parse import urlparse
        u=urlparse(url.strip())
        return u.scheme in {'http','https'} and (u.hostname or '').lower() in {'127.0.0.1','localhost','::1'}
    except Exception:
        return False

def _apply_system_settings(db:Session):
    for row in db.query(SystemSetting).all():
        if row.key not in SYSTEM_SETTING_KEYS: continue
        try: value=json.loads(row.value_json)
        except Exception: continue
        try: setattr(settings,row.key,value)
        except Exception: pass

def _system_settings_json():
    return {k:getattr(settings,k) for k in sorted(SYSTEM_SETTING_KEYS)}

# Load persisted overrides after tables exist. These values remain outside .env so upgrades preserve them.
with SessionLocal() as _settings_db:
    _apply_system_settings(_settings_db)


def ip(req:Request): return req.client.host if req.client else ''
def is_local(req:Request): return ip(req) in {'127.0.0.1','::1'}
def public_user(u): return {'id':u.id,'username':u.username,'display_name':u.display_name,'role':u.role,'active':u.active,'deleted':u.deleted,'must_change_password':u.must_change_password,'created_at':u.created_at.isoformat()}
def need_vault(db,u,vault_id,perm):
    v=db.get(Vault,vault_id)
    if not v or not v.active: raise HTTPException(404,'Vault not found')
    p=vault_permissions(db,u,vault_id)
    if not p.get(perm): raise HTTPException(403,f'Vault {perm} permission required')
    return v,p

def need_vault_any_state(db,u,vault_id,perm='manage'):
    v=db.get(Vault,vault_id)
    if not v: raise HTTPException(404,'Vault not found')
    p=vault_permissions(db,u,vault_id)
    if not p.get(perm): raise HTTPException(403,f'Vault {perm} permission required')
    return v,p

@app.get('/')
def home(): return FileResponse(FRONTEND/'index.html')
@app.get('/api/health')
def health(): return {'status':'ok','mode':'offline','name':settings.app_name,'version':'2.0.10'}
@app.get('/api/setup/status')
def setup_status(db:Session=Depends(get_db)): return {'required':db.query(User).count()==0,'remote_allowed':settings.allow_remote_bootstrap}
@app.post('/api/setup/admin')
def setup_admin(p:SetupIn,req:Request,response:Response,db:Session=Depends(get_db)):
    rate_limit('setup:'+ip(req),5,600)
    if db.query(User).count()!=0: raise HTTPException(409,'System already initialized')
    if not is_local(req) and not settings.allow_remote_bootstrap: raise HTTPException(403,'First administrator must be created from localhost')
    if not password_ok(p.password): raise HTTPException(400,'Password must be 14+ characters with upper/lowercase, number, and symbol')
    u=User(username=p.username.strip().lower(),display_name=p.display_name.strip(),password_hash=hash_password(p.password),role='admin');db.add(u);db.commit();db.refresh(u)
    csrf=create_session(db,u,response);audit(db,'BOOTSTRAP_ADMIN','Initial administrator created',user=u,ip=ip(req));return {'user':public_user(u),'csrf':csrf}
@app.post('/api/auth/login')
def login(p:LoginIn,req:Request,response:Response,db:Session=Depends(get_db)):
    rate_limit('login:'+ip(req),12,300);u=db.query(User).filter(User.username==p.username.strip().lower()).first()
    if not u or u.deleted or not u.active: raise HTTPException(401,'Invalid credentials')
    if u.locked_until and u.locked_until>datetime.utcnow(): raise HTTPException(423,'Account temporarily locked')
    if not verify_password(u.password_hash,p.password):
        u.failed_logins+=1
        if u.failed_logins>=6: u.locked_until=datetime.utcnow()+timedelta(minutes=15);u.failed_logins=0
        db.commit();audit(db,'LOGIN_FAILED','Invalid credentials',user=u,ip=ip(req));raise HTTPException(401,'Invalid credentials')
    u.failed_logins=0;u.locked_until=None;db.commit();csrf=create_session(db,u,response);audit(db,'LOGIN','Successful login',user=u,ip=ip(req));return {'user':public_user(u),'csrf':csrf}
@app.post('/api/auth/change-password')
def change_password(p:ChangePasswordIn,req:Request,u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    if not verify_password(u.password_hash,p.current_password): raise HTTPException(400,'Current password is incorrect')
    if not password_ok(p.new_password): raise HTTPException(400,'New password must be 14+ characters with upper/lowercase, number, and symbol')
    if p.current_password==p.new_password: raise HTTPException(400,'New password must be different')
    u.password_hash=hash_password(p.new_password);u.must_change_password=False;db.commit();audit(db,'CHANGE_PASSWORD','',user=u,ip=ip(req));return {'ok':True}

@app.post('/api/auth/logout')
def logout(req:Request,response:Response,u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    token=req.cookies.get('nexus_session');
    if token:
        from app.security.auth import hash_token
        db.query(SessionToken).filter(SessionToken.token_hash==hash_token(token)).delete();db.commit()
    response.delete_cookie('nexus_session',path='/');audit(db,'LOGOUT','',user=u,ip=ip(req));return {'ok':True}
@app.get('/api/auth/me')
def me(req:Request,u:User=Depends(current_user),db:Session=Depends(get_db)):
    token=req.cookies.get('nexus_session','')
    csrf=csrf_for_session_cookie(token)
    # Do not rotate or overwrite the legacy hash here. This keeps already-open
    # pre-2.0.8 tabs valid until their normal session expiry.
    return {'user':public_user(u),'csrf':csrf}

@app.get('/api/users')
def users(u:User=Depends(role_required('admin')),db:Session=Depends(get_db)): return [public_user(x) for x in db.query(User).order_by(User.deleted,User.username).all()]
@app.post('/api/users')
def create_user(p:UserIn,req:Request,u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    if u.role!='admin': raise HTTPException(403)
    if p.role not in ROLES: raise HTTPException(400,'Invalid role')
    if not password_ok(p.password): raise HTTPException(400,'Password must be 14+ characters with upper/lowercase, number, and symbol')
    name=p.username.strip().lower()
    if db.query(User).filter_by(username=name).first(): raise HTTPException(409,'Username already exists')
    x=User(username=name,display_name=p.display_name.strip(),role=p.role,password_hash=hash_password(p.password),active=p.active,must_change_password=True);db.add(x);db.commit();db.refresh(x);audit(db,'CREATE_USER',name,user=u,ip=ip(req));return public_user(x)
@app.patch('/api/users/{user_id}')
def edit_user(user_id:int,p:UserPatch,req:Request,u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    if u.role!='admin':raise HTTPException(403)
    x=db.get(User,user_id)
    if not x or x.deleted:raise HTTPException(404,'User not found')
    if p.role is not None:
        if p.role not in ROLES:raise HTTPException(400,'Invalid role')
        x.role=p.role
    if p.display_name is not None:x.display_name=p.display_name.strip()
    if p.active is not None:
        if x.id==u.id and not p.active:raise HTTPException(400,'You cannot deactivate your own active session')
        x.active=p.active
    if p.password is not None:
        if not password_ok(p.password):raise HTTPException(400,'Password does not meet policy')
        x.password_hash=hash_password(p.password);x.must_change_password=True;db.query(SessionToken).filter(SessionToken.user_id==x.id).delete()
    db.commit();audit(db,'EDIT_USER',x.username,user=u,ip=ip(req));return public_user(x)
@app.delete('/api/users/{user_id}')
def delete_user(user_id:int,req:Request,u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    if u.role!='admin':raise HTTPException(403)
    x=db.get(User,user_id)
    if not x or x.deleted:raise HTTPException(404,'User not found')
    if x.id==u.id:raise HTTPException(400,'You cannot delete your own account')
    old=x.username;x.active=False;x.deleted=True;x.username=f'deleted-{x.id}-{secrets.token_hex(4)}';x.display_name='Deleted user';x.password_hash=hash_password(secrets.token_urlsafe(48));db.query(SessionToken).filter(SessionToken.user_id==x.id).delete();db.commit();audit(db,'DELETE_USER',old,user=u,ip=ip(req));return {'ok':True}

@app.get('/api/vaults')
def vaults(u:User=Depends(current_user),db:Session=Depends(get_db)):
    q=db.query(Vault).filter(Vault.active==True)
    if u.role not in {'admin','knowledge_admin'}:
        ids=[a.vault_id for a in db.query(VaultAccess).filter(VaultAccess.user_id==u.id,VaultAccess.can_read==True).all()];q=q.filter(Vault.id.in_(ids or [-1]))
    out=[]
    for v in q.order_by(Vault.created_at.desc()).all():
        p=vault_permissions(db,u,v.id);out.append({'id':v.id,'name':v.name,'title':v.title,'department':v.department,'documents':len(v.documents),'permissions':p})
    return out
@app.post('/api/vaults')
def create_vault(p:VaultIn,req:Request,u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    if u.role not in {'admin','knowledge_admin'}:raise HTTPException(403)
    v=Vault(**p.model_dump());db.add(v);db.commit();db.refresh(v);audit(db,'CREATE_VAULT',v.name,v.id,u,ip(req));return {'id':v.id,'name':v.name,'title':v.title,'department':v.department}
@app.patch('/api/vaults/{vault_id}')
def edit_vault(vault_id:int,p:VaultPatch,req:Request,u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    v,perm=need_vault(db,u,vault_id,'manage')
    for k,val in p.model_dump(exclude_none=True).items():setattr(v,k,val)
    db.commit();audit(db,'EDIT_VAULT',v.name,v.id,u,ip(req));return {'ok':True}

@app.get('/api/vaults/archived')
def archived_vaults(u:User=Depends(role_required('admin','knowledge_admin')),db:Session=Depends(get_db)):
    rows=db.query(Vault).filter(Vault.active==False).order_by(Vault.created_at.desc()).all()
    return [{'id':v.id,'name':v.name,'title':v.title,'department':v.department,'documents':db.query(Document).filter_by(vault_id=v.id).count(),'created_at':v.created_at.isoformat()} for v in rows]

@app.post('/api/vaults/{vault_id}/archive')
def archive_vault(vault_id:int,req:Request,u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    v,_=need_vault_any_state(db,u,vault_id,'manage')
    if not v.active: return {'ok':True,'archived':True}
    name=v.name; v.active=False; db.commit()
    audit(db,'ARCHIVE_VAULT',name,vault_id,u,ip(req))
    return {'ok':True,'archived':True}

@app.post('/api/vaults/{vault_id}/restore')
def restore_vault(vault_id:int,req:Request,u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    if u.role not in {'admin','knowledge_admin'}: raise HTTPException(403,'Administrator or Knowledge Admin role required')
    v=db.get(Vault,vault_id)
    if not v: raise HTTPException(404,'Vault not found')
    if v.active: return {'ok':True,'restored':True}
    name=v.name; v.active=True; db.commit()
    audit(db,'RESTORE_VAULT',name,vault_id,u,ip(req))
    return {'ok':True,'restored':True}

@app.delete('/api/vaults/{vault_id}')
def delete_vault(vault_id:int,p:VaultDeleteIn,req:Request,u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    v,_=need_vault_any_state(db,u,vault_id,'manage')
    if p.confirm_name.strip()!=v.name:
        raise HTTPException(400,'Vault name confirmation does not match')
    name=v.name
    docs=db.query(Document).filter_by(vault_id=vault_id).all()
    paths=[Path(d.source_path) for d in docs]
    doc_count=len(docs)
    # Explicit child cleanup keeps deletion reliable even if a future DB backend does not honor SQLite cascades.
    doc_ids=[d.id for d in docs]
    for i in range(0,len(doc_ids),500):
        batch=doc_ids[i:i+500]
        db.query(Chunk).filter(Chunk.document_id.in_(batch)).delete(synchronize_session=False)
        db.query(Document).filter(Document.id.in_(batch)).delete(synchronize_session=False)
    db.query(ChatMessage).filter_by(vault_id=vault_id).delete(synchronize_session=False)
    db.query(VaultAccess).filter_by(vault_id=vault_id).delete(synchronize_session=False)
    db.query(VaultSetting).filter_by(vault_id=vault_id).delete(synchronize_session=False)
    db.delete(v); db.commit()
    failed=0
    for path in paths:
        try: path.unlink(missing_ok=True)
        except Exception: failed+=1
    detail=f'Permanently deleted vault "{name}" with {doc_count} document(s)'
    if failed: detail+=f'; {failed} encrypted original(s) could not be unlinked'
    audit(db,'DELETE_VAULT',detail,vault_id,u,ip(req))
    return {'ok':True,'deleted':True,'documents_deleted':doc_count,'file_delete_failures':failed}
@app.get('/api/vaults/{vault_id}/documents')
def documents(vault_id:int,u:User=Depends(current_user),db:Session=Depends(get_db)):
    _,perm=need_vault(db,u,vault_id,'read');q=db.query(Document).filter_by(vault_id=vault_id)
    if not perm['restricted']:q=q.filter(Document.sensitivity!='restricted')
    return [{'id':d.id,'filename':d.filename,'source_type':d.source_type,'size_bytes':d.size_bytes,'sensitivity':d.sensitivity,'malware_status':d.malware_status,'created_at':d.created_at.isoformat()} for d in q.order_by(Document.created_at.desc()).all()]
@app.post('/api/vaults/{vault_id}/upload')
async def upload(vault_id:int,req:Request,files:list[UploadFile]=File(...),u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    _,perm=need_vault(db,u,vault_id,'upload')
    if len(files)>settings.max_files_per_upload:raise HTTPException(413,f'Maximum {settings.max_files_per_upload} files per upload')
    results=[]; vs=vault_setting(db,vault_id); allowed={x.strip().lower() for x in (vs.allowed_extensions or DEFAULT_EXTS).split(',') if x.strip()}
    image_exts={'.png','.jpg','.jpeg','.tif','.tiff','.bmp','.webp'}; media_exts={'.mp3','.wav','.m4a','.mp4','.mov','.avi','.mkv'}
    for f in files:
        try:
            ext=Path(f.filename or '').suffix.lower()
            if ext not in allowed: raise HTTPException(415,f'{ext or "This file type"} is disabled in this vault settings')
            if ext in image_exts and not vs.ocr_enabled: raise HTTPException(415,'OCR is disabled for this vault')
            if ext in media_exts and not vs.transcribe_media: raise HTTPException(415,'Audio/video transcription is disabled for this vault')
            if ext=='.zip' and not vs.extract_archives: raise HTTPException(415,'Archive extraction is disabled for this vault')
            doc,chunks,dup,flags=await ingest_upload(db,vault_id,f);results.append({'filename':doc.filename,'document_id':doc.id,'chunks':chunks,'duplicate':dup,'source_type':doc.source_type,'sensitivity':doc.sensitivity,'detected':flags})
        except HTTPException as e:results.append({'filename':f.filename,'error':e.detail})
        except Exception as e:results.append({'filename':f.filename,'error':type(e).__name__+': '+str(e)[:400]})
    audit(db,'UPLOAD',f'{len(files)} file(s)',vault_id,u,ip(req));return results
@app.get('/api/documents/{doc_id}/download')
def download(doc_id:int,req:Request,u:User=Depends(current_user),db:Session=Depends(get_db)):
    d=db.get(Document,doc_id)
    if not d:raise HTTPException(404)
    _,perm=need_vault(db,u,d.vault_id,'read')
    if d.sensitivity=='restricted' and not perm['restricted']:raise HTTPException(403,'Restricted document permission required')
    audit(db,'DOWNLOAD_DOCUMENT',d.filename,d.vault_id,u,ip(req))
    import io
    headers={'Content-Disposition':f'attachment; filename="{Path(d.filename).name.replace(chr(34),"")}"'}
    return StreamingResponse(decrypt_file_iter(Path(d.source_path)),media_type=d.mime_type or 'application/octet-stream',headers=headers)
@app.delete('/api/documents/{doc_id}')
def delete_document(doc_id:int,req:Request,u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    d=db.get(Document,doc_id)
    if not d:raise HTTPException(404)
    _,_=need_vault(db,u,d.vault_id,'manage');path=Path(d.source_path);name=d.filename;vid=d.vault_id;db.delete(d);db.commit();path.unlink(missing_ok=True);audit(db,'DELETE_DOCUMENT',name,vid,u,ip(req));return {'ok':True}


@app.post('/api/vaults/{vault_id}/documents/bulk-delete')
def bulk_delete_documents(vault_id:int,p:BulkDeleteDocumentsIn,req:Request,u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    need_vault(db,u,vault_id,'manage')
    ids=sorted(set(int(x) for x in p.document_ids if int(x)>0))
    if not p.delete_all and not ids: raise HTTPException(400,'Select at least one document')
    q=db.query(Document.id,Document.source_path,Document.filename).filter(Document.vault_id==vault_id)
    if not p.delete_all: q=q.filter(Document.id.in_(ids))
    rows=q.all()
    if not rows: return {'ok':True,'deleted':0}
    target_ids=[r.id for r in rows]
    paths=[Path(r.source_path) for r in rows]
    names=[r.filename for r in rows]
    # Delete index chunks and document metadata in bounded batches, then commit once.
    for i in range(0,len(target_ids),500):
        batch=target_ids[i:i+500]
        db.query(Chunk).filter(Chunk.document_id.in_(batch)).delete(synchronize_session=False)
        db.query(Document).filter(Document.vault_id==vault_id,Document.id.in_(batch)).delete(synchronize_session=False)
    db.commit()
    failed_files=0
    for path in paths:
        try: path.unlink(missing_ok=True)
        except Exception: failed_files+=1
    detail=f'{len(target_ids)} document(s) bulk deleted'
    if p.delete_all: detail+=' (DELETE ALL)'
    if failed_files: detail+=f'; {failed_files} encrypted original(s) could not be unlinked'
    if names: detail+=f'; sample: {", ".join(names[:5])}'[:800]
    audit(db,'BULK_DELETE_DOCUMENTS',detail,vault_id,u,ip(req))
    return {'ok':True,'deleted':len(target_ids),'file_delete_failures':failed_files}


DEFAULT_EXTS='.txt,.md,.log,.ini,.cfg,.conf,.py,.ps1,.sh,.yaml,.yml,.bat,.cmd,.js,.ts,.sql,.toml,.properties,.json,.csv,.tsv,.html,.htm,.xml,.rtf,.doc,.dot,.docx,.dotx,.docm,.dotm,.xls,.xlt,.xlsx,.xlsm,.xltx,.xltm,.ppt,.pps,.pot,.pptx,.pptm,.ppsx,.potx,.pdf,.eml,.msg,.pst,.zip,.png,.jpg,.jpeg,.tif,.tiff,.bmp,.webp,.mp3,.wav,.m4a,.mp4,.mov,.avi,.mkv'
def vault_setting(db,vault_id):
    x=db.query(VaultSetting).filter_by(vault_id=vault_id).first()
    if not x:
        x=VaultSetting(vault_id=vault_id,allowed_extensions=DEFAULT_EXTS);db.add(x);db.commit();db.refresh(x)
    return x
def setting_json(x): return {k:getattr(x,k) for k in ['auto_index','ocr_enabled','transcribe_media','extract_archives','malware_scan','auto_categorize','chunk_chars','allowed_extensions']}
@app.get('/api/vaults/{vault_id}/settings')
def get_vault_settings(vault_id:int,u:User=Depends(current_user),db:Session=Depends(get_db)):
    need_vault(db,u,vault_id,'read');return setting_json(vault_setting(db,vault_id))
@app.put('/api/vaults/{vault_id}/settings')
def put_vault_settings(vault_id:int,p:VaultSettingsIn,req:Request,u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    need_vault(db,u,vault_id,'manage');x=vault_setting(db,vault_id)
    for k,v in p.model_dump().items():setattr(x,k,v)
    db.commit();audit(db,'VAULT_SETTINGS','Updated ingestion settings',vault_id,u,ip(req));return setting_json(x)
@app.get('/api/vaults/{vault_id}/chat')
def chat_history(vault_id:int,u:User=Depends(current_user),db:Session=Depends(get_db)):
    need_vault(db,u,vault_id,'read');rows=db.query(ChatMessage).filter_by(vault_id=vault_id,user_id=u.id).order_by(ChatMessage.created_at.asc()).limit(300).all();out=[]
    for m in rows:
        try:content=decrypt_bytes(m.content_enc).decode('utf-8','replace')
        except Exception:content='[Unable to decrypt message]'
        out.append({'id':m.id,'role':m.role,'content':content,'created_at':m.created_at.isoformat()})
    return out
@app.delete('/api/vaults/{vault_id}/chat')
def clear_chat(vault_id:int,req:Request,u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    need_vault(db,u,vault_id,'read');db.query(ChatMessage).filter_by(vault_id=vault_id,user_id=u.id).delete();db.commit();audit(db,'CLEAR_CHAT','Cleared personal vault chat',vault_id,u,ip(req));return {'ok':True}

@app.post('/api/chat')
async def chat(p:ChatIn,req:Request,u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    rate_limit('chat:'+str(u.id),30,60)
    _,perm=need_vault(db,u,p.vault_id,'read')
    db.add(ChatMessage(vault_id=p.vault_id,user_id=u.id,role='user',content_enc=encrypt_bytes(p.question.encode())));db.commit()
    ctx=search(db,p.vault_id,p.question,perm['restricted'],8)
    score=ctx[0][0] if ctx else 0.0
    # AUTO uses vault evidence only when retrieval is meaningfully related; otherwise it behaves like normal local chat.
    resolved_mode=p.mode
    if p.mode=='auto': resolved_mode='vault' if ctx and score>=0.22 else 'general'
    if resolved_mode=='general':
        text,llm_used,answer_mode=await answer_general_chat(p.question)
        sources=[]; evidence='none'
    else:
        text,sources,llm_used,answer_mode=await answer_with_local_llm(p.question,ctx)
        evidence='none' if not ctx else ('high' if len(ctx)>=3 and score>.2 else 'limited')
    db.add(ChatMessage(vault_id=p.vault_id,user_id=u.id,role='assistant',content_enc=encrypt_bytes(text.encode())));db.commit()
    audit(db,'QUERY',f'mode={p.mode}; resolved={resolved_mode}; '+p.question[:900],p.vault_id,u,ip(req))
    return {'answer':text,'sources':sources,'llm_used':llm_used,'answer_mode':answer_mode,'requested_mode':p.mode,'resolved_mode':resolved_mode,'evidence':evidence}


@app.get('/api/llm/status')
async def llm_status(u:User=Depends(current_user)):
    return await local_llm_status()

@app.get('/api/vaults/{vault_id}/access')
def access_list(vault_id:int,u:User=Depends(current_user),db:Session=Depends(get_db)):
    need_vault(db,u,vault_id,'manage');rows=db.query(VaultAccess).filter_by(vault_id=vault_id).all();return [{'id':a.id,'user_id':a.user_id,'username':db.get(User,a.user_id).username if db.get(User,a.user_id) else '?','can_read':a.can_read,'can_upload':a.can_upload,'can_manage':a.can_manage,'can_restricted':a.can_restricted} for a in rows]
@app.post('/api/vaults/{vault_id}/access')
def access_set(vault_id:int,p:AccessIn,req:Request,u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    need_vault(db,u,vault_id,'manage');target=db.get(User,p.user_id)
    if not target or target.deleted:raise HTTPException(404,'User not found')
    a=db.query(VaultAccess).filter_by(user_id=p.user_id,vault_id=vault_id).first() or VaultAccess(user_id=p.user_id,vault_id=vault_id);db.add(a)
    for k in ['can_read','can_upload','can_manage','can_restricted']:setattr(a,k,getattr(p,k))
    db.commit();audit(db,'SET_VAULT_ACCESS',f'user={target.username}',vault_id,u,ip(req));return {'ok':True}

@app.get('/api/audit')
def get_audit(u:User=Depends(role_required('admin','auditor')),db:Session=Depends(get_db)):
    rows=db.query(AuditEvent).order_by(AuditEvent.created_at.desc()).limit(500).all();return [{'id':r.id,'time':r.created_at.isoformat(),'user':r.username,'action':r.action,'vault_id':r.vault_id,'detail':r.detail,'ip':r.ip,'hash':r.event_hash[:12]} for r in rows]

@app.get('/api/audit/export')
def export_audit(req:Request,format:str='csv',u:User=Depends(role_required('admin','auditor')),db:Session=Depends(get_db)):
    fmt=(format or 'csv').lower()
    if fmt not in {'csv','txt'}: raise HTTPException(400,'format must be csv or txt')
    audit(db,'EXPORT_AUDIT',f'format={fmt}',user=u,ip=ip(req))
    rows=db.query(AuditEvent).order_by(AuditEvent.created_at.asc()).all()
    stamp=datetime.now().strftime('%Y%m%d-%H%M%S')
    fields=['id','time','user_id','user','action','vault_id','detail','ip','prev_hash','event_hash']
    def safe_csv(v):
        x='' if v is None else str(v)
        if x[:1] in {'=','+','-','@'}: x="'"+x
        return x
    if fmt=='csv':
        out=io.StringIO(newline='')
        w=csv.writer(out,lineterminator='\r\n')
        w.writerow(fields)
        for r in rows:
            w.writerow([safe_csv(r.id),safe_csv(r.created_at.isoformat()),safe_csv(r.user_id),safe_csv(r.username),safe_csv(r.action),safe_csv(r.vault_id),safe_csv(r.detail),safe_csv(r.ip),safe_csv(r.prev_hash),safe_csv(r.event_hash)])
        body=('\ufeff'+out.getvalue()).encode('utf-8')
        return Response(content=body,media_type='text/csv; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="hive-mind-audit-{stamp}.csv"','X-Content-Type-Options':'nosniff'})
    def clean_txt(v): return ('' if v is None else str(v)).replace('\\','\\\\').replace('\t','\\t').replace('\r','\\r').replace('\n','\\n')
    lines=['\t'.join(fields)]
    for r in rows:
        lines.append('\t'.join(clean_txt(v) for v in [r.id,r.created_at.isoformat(),r.user_id,r.username,r.action,r.vault_id,r.detail,r.ip,r.prev_hash,r.event_hash]))
    body=('\ufeff'+'\r\n'.join(lines)+'\r\n').encode('utf-8')
    return Response(content=body,media_type='text/plain; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="hive-mind-audit-{stamp}.txt"','X-Content-Type-Options':'nosniff'})
@app.get('/api/system/status')
def status(u:User=Depends(role_required('admin')),db:Session=Depends(get_db)):
    ok,bad=verify_chain(db);dbpath=settings.data_dir/'nexus.db';return {'database':str(dbpath),'database_exists':dbpath.exists(),'database_bytes':dbpath.stat().st_size if dbpath.exists() else 0,'data_dir':str(settings.data_dir.resolve()),'users':db.query(User).filter(User.deleted==False).count(),'vaults':db.query(Vault).filter(Vault.active==True).count(),'documents':db.query(Document).count(),'audit_chain_ok':ok,'audit_bad_event':bad,'encryption':'AES-256-GCM; master key DPAPI-wrapped on Windows'}

@app.get('/api/system/settings')
def get_system_settings(u:User=Depends(role_required('admin')),db:Session=Depends(get_db)):
    return _system_settings_json()

@app.put('/api/system/settings')
def put_system_settings(p:SystemSettingsIn,req:Request,u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    if u.role!='admin': raise HTTPException(403,'Administrator role required')
    vals=p.model_dump()
    vals['local_llm_model']=vals['local_llm_model'].strip()
    vals['local_llm_url']=vals['local_llm_url'].strip()
    vals['clamav_path']=vals['clamav_path'].strip()
    if not _safe_local_llm_url(vals['local_llm_url']):
        raise HTTPException(400,'Local LLM URL must use http/https and resolve only to 127.0.0.1, localhost, or ::1')
    if vals['require_malware_scanner'] and not vals['clamav_path']:
        raise HTTPException(400,'A ClamAV executable path is required when malware scanning is mandatory')
    changed={}
    for key,value in vals.items():
        old=getattr(settings,key)
        if old!=value: changed[key]={'from':old,'to':value}
        row=db.query(SystemSetting).filter_by(key=key).first()
        if not row:
            row=SystemSetting(key=key);db.add(row)
        row.value_json=json.dumps(value,separators=(',',':'))
        row.updated_by=u.username
        setattr(settings,key,value)
    db.commit()
    audit(db,'UPDATE_SYSTEM_SETTINGS',json.dumps(changed,separators=(',',':'))[:8000],user=u,ip=ip(req))
    return {'ok':True,'settings':_system_settings_json(),'changed':list(changed.keys())}
@app.post('/api/system/backup')
def backup(p:BackupIn,req:Request,u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    if u.role!='admin':raise HTTPException(403)
    try:path=create_backup(p.passphrase)
    except ValueError as e:raise HTTPException(400,str(e))
    audit(db,'CREATE_BACKUP',path.name,user=u,ip=ip(req));return {'ok':True,'file':path.name,'server_path':str(path)}

@app.post('/api/system/restore/prepare')
async def restore_prepare(req:Request,backup:UploadFile=File(...),passphrase:str=Form(...),u:User=Depends(require_csrf),db:Session=Depends(get_db)):
    if u.role!='admin': raise HTTPException(403,'Administrator role required')
    if not backup.filename or not backup.filename.lower().endswith('.nxb'): raise HTTPException(415,'Select a HIVE MIND .nxb backup')
    if len(passphrase)<16: raise HTTPException(400,'Backup passphrase must be at least 16 characters')
    staging=settings.data_dir/'backups'/'restore-upload.nxb'
    staging.parent.mkdir(parents=True,exist_ok=True)
    total=0
    try:
        with staging.open('wb') as f:
            while True:
                block=await backup.read(1024*1024)
                if not block: break
                total+=len(block)
                if total>settings.max_upload_mb*1024*1024: raise HTTPException(413,'Backup exceeds configured maximum size')
                f.write(block)
        result=prepare_restore(staging,passphrase)
        audit(db,'PREPARE_RESTORE',f'Validated backup {backup.filename}; restart required',user=u,ip=ip(req))
        return result
    except HTTPException: raise
    except Exception as e: raise HTTPException(400,f'Backup validation failed: {e}')
    finally:
        try: staging.unlink(missing_ok=True)
        except Exception: pass

