from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, sessionmaker
from app.config import settings

connect_args={"check_same_thread":False} if settings.db_url.startswith("sqlite") else {}
engine=create_engine(settings.db_url,connect_args=connect_args,pool_pre_ping=True)
if settings.db_url.startswith("sqlite"):
    @event.listens_for(engine,"connect")
    def _sqlite(dbapi_conn, _):
        cur=dbapi_conn.cursor(); cur.execute("PRAGMA journal_mode=WAL"); cur.execute("PRAGMA foreign_keys=ON"); cur.execute("PRAGMA synchronous=FULL"); cur.close()
SessionLocal=sessionmaker(bind=engine,autoflush=False,autocommit=False,expire_on_commit=False)
class Base(DeclarativeBase): pass

def get_db():
    db=SessionLocal()
    try: yield db
    finally: db.close()
