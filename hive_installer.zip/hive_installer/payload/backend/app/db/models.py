from datetime import datetime
from sqlalchemy import String, Text, DateTime, ForeignKey, Integer, LargeBinary, Boolean, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.database import Base

class User(Base):
    __tablename__='users'
    id: Mapped[int]=mapped_column(primary_key=True)
    username: Mapped[str]=mapped_column(String(120),unique=True,index=True)
    display_name: Mapped[str]=mapped_column(String(200))
    password_hash: Mapped[str]=mapped_column(String(500))
    role: Mapped[str]=mapped_column(String(40),default='user',index=True)
    active: Mapped[bool]=mapped_column(Boolean,default=True)
    deleted: Mapped[bool]=mapped_column(Boolean,default=False)
    must_change_password: Mapped[bool]=mapped_column(Boolean,default=False)
    failed_logins: Mapped[int]=mapped_column(Integer,default=0)
    locked_until: Mapped[datetime|None]=mapped_column(DateTime,nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    updated_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow,onupdate=datetime.utcnow)

class SessionToken(Base):
    __tablename__='sessions'
    id: Mapped[int]=mapped_column(primary_key=True)
    user_id: Mapped[int]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),index=True)
    token_hash: Mapped[str]=mapped_column(String(64),unique=True,index=True)
    csrf_hash: Mapped[str]=mapped_column(String(64))
    expires_at: Mapped[datetime]=mapped_column(DateTime,index=True)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

class Vault(Base):
    __tablename__='vaults'
    id: Mapped[int]=mapped_column(primary_key=True)
    name: Mapped[str]=mapped_column(String(200),index=True)
    title: Mapped[str|None]=mapped_column(String(200),nullable=True)
    department: Mapped[str|None]=mapped_column(String(200),nullable=True,index=True)
    active: Mapped[bool]=mapped_column(Boolean,default=True)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    documents=relationship('Document',back_populates='vault',cascade='all, delete-orphan')

class VaultAccess(Base):
    __tablename__='vault_access'; __table_args__=(UniqueConstraint('user_id','vault_id'),)
    id: Mapped[int]=mapped_column(primary_key=True)
    user_id: Mapped[int]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),index=True)
    vault_id: Mapped[int]=mapped_column(ForeignKey('vaults.id',ondelete='CASCADE'),index=True)
    can_read: Mapped[bool]=mapped_column(Boolean,default=True)
    can_upload: Mapped[bool]=mapped_column(Boolean,default=False)
    can_manage: Mapped[bool]=mapped_column(Boolean,default=False)
    can_restricted: Mapped[bool]=mapped_column(Boolean,default=False)

class Document(Base):
    __tablename__='documents'
    id: Mapped[int]=mapped_column(primary_key=True)
    vault_id: Mapped[int]=mapped_column(ForeignKey('vaults.id',ondelete='CASCADE'),index=True)
    filename: Mapped[str]=mapped_column(String(500))
    source_type: Mapped[str]=mapped_column(String(80),index=True)
    mime_type: Mapped[str|None]=mapped_column(String(200),nullable=True)
    source_path: Mapped[str]=mapped_column(String(1000))
    sha256: Mapped[str]=mapped_column(String(64),index=True)
    size_bytes: Mapped[int]=mapped_column(Integer,default=0)
    sensitivity: Mapped[str]=mapped_column(String(30),default='normal',index=True)
    malware_status: Mapped[str]=mapped_column(String(30),default='not_scanned')
    created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    vault=relationship('Vault',back_populates='documents')
    chunks=relationship('Chunk',back_populates='document',cascade='all, delete-orphan')

class Chunk(Base):
    __tablename__='chunks'
    id: Mapped[int]=mapped_column(primary_key=True)
    document_id: Mapped[int]=mapped_column(ForeignKey('documents.id',ondelete='CASCADE'),index=True)
    position: Mapped[int]=mapped_column(Integer)
    text_enc: Mapped[bytes]=mapped_column(LargeBinary)
    embedding_enc: Mapped[bytes]=mapped_column(LargeBinary)
    document=relationship('Document',back_populates='chunks')

class AuditEvent(Base):
    __tablename__='audit_events'
    id: Mapped[int]=mapped_column(primary_key=True)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow,index=True)
    user_id: Mapped[int|None]=mapped_column(Integer,nullable=True,index=True)
    username: Mapped[str]=mapped_column(String(200),default='system')
    action: Mapped[str]=mapped_column(String(80),index=True)
    vault_id: Mapped[int|None]=mapped_column(Integer,nullable=True,index=True)
    detail: Mapped[str]=mapped_column(Text,default='')
    ip: Mapped[str]=mapped_column(String(64),default='')
    prev_hash: Mapped[str]=mapped_column(String(64),default='')
    event_hash: Mapped[str]=mapped_column(String(64),unique=True,index=True)


class VaultSetting(Base):
    __tablename__='vault_settings'
    id: Mapped[int]=mapped_column(primary_key=True)
    vault_id: Mapped[int]=mapped_column(ForeignKey('vaults.id',ondelete='CASCADE'),unique=True,index=True)
    auto_index: Mapped[bool]=mapped_column(Boolean,default=True)
    ocr_enabled: Mapped[bool]=mapped_column(Boolean,default=True)
    transcribe_media: Mapped[bool]=mapped_column(Boolean,default=False)
    extract_archives: Mapped[bool]=mapped_column(Boolean,default=True)
    malware_scan: Mapped[bool]=mapped_column(Boolean,default=True)
    auto_categorize: Mapped[bool]=mapped_column(Boolean,default=True)
    chunk_chars: Mapped[int]=mapped_column(Integer,default=1200)
    allowed_extensions: Mapped[str]=mapped_column(Text,default='')
    updated_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow,onupdate=datetime.utcnow)

class ChatMessage(Base):
    __tablename__='chat_messages'
    id: Mapped[int]=mapped_column(primary_key=True)
    vault_id: Mapped[int]=mapped_column(ForeignKey('vaults.id',ondelete='CASCADE'),index=True)
    user_id: Mapped[int]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),index=True)
    role: Mapped[str]=mapped_column(String(20))
    content_enc: Mapped[bytes]=mapped_column(LargeBinary)
    sources_json_enc: Mapped[bytes|None]=mapped_column(LargeBinary,nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow,index=True)


class SystemSetting(Base):
    __tablename__='system_settings'
    id: Mapped[int]=mapped_column(primary_key=True)
    key: Mapped[str]=mapped_column(String(120),unique=True,index=True)
    value_json: Mapped[str]=mapped_column(Text,default='null')
    updated_by: Mapped[str]=mapped_column(String(200),default='system')
    updated_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow,onupdate=datetime.utcnow)
