import os,sys,compileall
from pathlib import Path
ROOT=Path(__file__).resolve().parent;os.chdir(ROOT);sys.path.insert(0,str(ROOT/'backend'))
print('HIVE MIND self-check')
print('Python:',sys.version.split()[0])
if not compileall.compile_dir(ROOT/'backend',quiet=1): raise SystemExit('Python compile check failed')
from app.config import settings
from app.security.guards import llm_url_is_safe
from app.security.crypto import master_key,encrypt_bytes,decrypt_bytes
assert decrypt_bytes(encrypt_bytes(b'test',b'x'),b'x')==b'test'
assert len(master_key())==32
print('Encryption round-trip: OK')
print('Local LLM URL safety:', 'OK' if llm_url_is_safe(settings.local_llm_url) else 'BLOCKED')
print('Bind:',settings.host,settings.port)
print('Allowed hosts:',settings.allowed_hosts)
print('Data directory:',settings.data_dir.resolve())
print('Self-check complete.')
