# HIVE MIND Security Deployment Checklist

## Required before sensitive multi-user deployment
- [ ] Dedicated server/service account; no daily-use administrator account.
- [ ] BitLocker/LUKS enabled on the HIVE MIND data volume.
- [ ] TLS reverse proxy configured; `HIVE_COOKIE_SECURE=true`.
- [ ] `HIVE_ALLOWED_HOSTS` limited to approved internal DNS names.
- [ ] Firewall denies Internet egress unless explicitly required for maintenance.
- [ ] LLM/inference endpoint is loopback or approved RFC1918/private address only.
- [ ] ClamAV or enterprise malware scanner configured; consider `HIVE_REQUIRE_MALWARE_SCANNER=true`.
- [ ] Backup passphrase escrowed securely and test restore completed.
- [ ] Admin, HR, auditor, and per-vault permissions reviewed.
- [ ] Retention/legal-hold/deletion policy approved by HR/legal/security.
- [ ] Dependency/SAST scan completed against the exact packaged versions.
- [ ] Penetration test performed for the intended network topology.

## Data-leak controls in this build
HIVE MIND does not expose filesystem paths to normal clients. Originals are decrypted only after authorization and streamed directly. Indexed chunk text and embeddings are encrypted at rest. Restricted secret-like values are redacted before indexing, while the original remains encrypted. Local LLM destinations are validated to loopback/private IP space and redirects are disabled.

## Known operational boundaries
Application encryption does not replace full-disk encryption, OS permissions, endpoint protection, or secure backups. Optional PST/media parsers are native/complex components and should be patched and sandboxed according to your environment. SQLite is appropriate for a secured single-node deployment; larger concurrent deployments should move metadata to PostgreSQL and vectors to pgvector/Qdrant behind private service interfaces while preserving the same authorization checks.
