@echo off
setlocal
cd /d "%~dp0"
title Repair HIVE MIND

echo This rebuilds ONLY the Python environment. storage\ is not touched.
if exist .venv rmdir /s /q .venv
call start_windows.bat
