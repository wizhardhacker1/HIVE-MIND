#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then python3 -m venv .venv; fi
if ! .venv/bin/python -c 'import fastapi,uvicorn,sqlalchemy,cryptography,argon2,fitz,docx,openpyxl,pptx,bs4,numpy,httpx' >/dev/null 2>&1; then .venv/bin/python -m pip install --disable-pip-version-check -r backend/requirements.txt; fi
[ -f .env ] || cp .env.example .env
mkdir -p storage
exec .venv/bin/python run.py
