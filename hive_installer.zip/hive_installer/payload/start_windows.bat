@echo off
setlocal
cd /d "%~dp0"
title HIVE MIND

echo.
echo ============================================================
echo   HIVE MIND - Secure Offline Knowledge Server
echo ============================================================
echo.

set "PYEXE="
where py >nul 2>&1 && (py -3.12 -c "import sys" >nul 2>&1 && set "PYEXE=py -3.12")
if not defined PYEXE where py >nul 2>&1 && (py -3.11 -c "import sys" >nul 2>&1 && set "PYEXE=py -3.11")
if not defined PYEXE where python >nul 2>&1 && set "PYEXE=python"
if not defined PYEXE (
  echo ERROR: Python 3.11 or 3.12 was not found.
  echo Install Python once, then run this file again.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating isolated HIVE MIND Python environment...
  %PYEXE% -m venv .venv || goto :fail
)

set "VPY=%CD%\.venv\Scripts\python.exe"
echo Checking required packages...
"%VPY%" -c "import fastapi,uvicorn,sqlalchemy,cryptography,argon2,fitz,docx,openpyxl,pptx,bs4,numpy,httpx" >nul 2>&1
if errorlevel 1 (
  echo Installing HIVE MIND dependencies into its private environment...
  "%VPY%" -m pip install --disable-pip-version-check -r backend\requirements.txt || goto :fail
)

if not exist ".env" copy /y ".env.example" ".env" >nul
if not exist "storage" mkdir storage

echo.
echo Starting HIVE MIND at http://127.0.0.1:8787
echo Close this window to stop the server. Stored data remains on disk.
echo.
start "" http://127.0.0.1:8787
"%VPY%" run.py
exit /b 0

:fail
echo.
echo HIVE MIND setup failed. See the error above. No HIVE MIND data was deleted.
pause
exit /b 1
