# HIVE MIND 1.1 — Secure Offline Knowledge Preservation

HIVE MIND is a local-first employee knowledge retention system. It ingests documented work history, encrypts source material and indexed text, and lets authorized users search/chat against the evidence without cloud APIs.

## One-click Windows start
1. Extract the folder to a local NTFS volume.
2. Double-click `start_windows.bat`.
3. On first launch, create the administrator in the browser at `http://127.0.0.1:8787`.
4. Closing the server window stops HIVE MIND but **does not delete data**. Persistent data is under `storage/`.

`repair_windows.bat` rebuilds only the Python virtual environment. It does not touch `storage/`.


## Local AI
This release is configured for **Meta Llama 3.2 3B** through a loopback-only Ollama runtime at `127.0.0.1:11434`. The full Windows installer detects/installs the runtime when possible and pulls `llama3.2:3b` automatically if the model is not already present. After provisioning, HIVE MIND sends RAG prompts only to that local endpoint.

## Security implemented
- Argon2id password hashing and minimum password policy.
- Server-side random sessions in HttpOnly, SameSite=Strict cookies.
- CSRF protection on state-changing API calls.
- Login throttling and temporary account lockout.
- Admin user create/edit/deactivate/delete; deletion is privacy-preserving soft deletion so audit history remains valid.
- Roles: admin, knowledge_admin, hr, manager, auditor, user.
- Explicit per-vault read/upload/manage/restricted permissions.
- AES-256-GCM encryption for originals, indexed chunk text, and embeddings.
- Random master key; Windows wraps it with DPAPI. Linux stores it mode 0600 and should use LUKS/full-disk encryption.
- Restricted-data detector/redactor for obvious private keys, AWS-style keys, password/token patterns, and SSNs before RAG indexing.
- Restricted originals remain encrypted and require restricted-document permission.
- File extension allowlist; executable/script container types are rejected unless explicitly supported text types.
- Upload count/size limits.
- Optional ClamAV gate and quarantine directory. Set `HIVE_REQUIRE_MALWARE_SCANNER=true` for deployments that require every upload to be scanned.
- Secure authorized document download endpoint; storage paths are never exposed to the browser.
- Local/private-network-only LLM URL guard; public Internet LLM destinations are rejected.
- Prompt-injection defense instruction: imported documents are untrusted evidence, never instructions.
- Tamper-evident SHA-256 chained audit events.
- CSP, frame denial, nosniff, no-referrer, no-store, and restrictive browser permissions headers.
- FastAPI interactive docs/OpenAPI endpoints disabled in production build.
- SQLite WAL + FULL synchronous mode for resilient single-node persistence.
- Passphrase-encrypted `.nxb` backups using scrypt + AES-GCM; consistent SQLite snapshot plus originals and encryption key.

## Data persistence
Persistent state lives under:

```
storage/
  nexus.db
  originals/
  quarantine/
  keys/master.key
  backups/
```

Do not put `storage/` inside a temporary/download-cleanup location. For a server deployment, point `HIVE_DATA_DIR` at a protected data volume.

## Supported ingestion
Base installation: DOCX, XLSX/XLSM, PPTX, PDF, EML, TXT/Markdown, CSV, JSON, HTML, configuration/source text files.

Windows installer capabilities:
- PST: `libpff-python-windows` is installed automatically.
- MSG: `extract-msg` is installed automatically.
- Audio/video: install `faster-whisper`, FFmpeg, and the Whisper model locally. The application uses `local_files_only=True` and will not download a model at runtime.
- Teams/Slack/SharePoint/OneDrive: ingest their exported JSON/HTML/files. Export-specific metadata adapters can be added without changing the security model.

## Backup
In **System & Security**, choose Create Backup and provide a strong 16+ character passphrase. The resulting file is stored under `storage/backups/`.

To restore, stop HIVE MIND, then:

```
.venv\Scripts\python.exe restore.py storage\backups\nexus-YYYYMMDD-HHMMSS.nxb
```

The restore tool creates a pre-restore safety copy first.

## Network deployment
The safe default binds only to `127.0.0.1`. For multi-user production use:
- Keep HIVE MIND bound to localhost or a private application interface behind an enterprise reverse proxy.
- Terminate TLS 1.2/1.3 at the proxy and set `HIVE_COOKIE_SECURE=true`.
- Set `HIVE_ALLOWED_HOSTS` to the real internal DNS name(s).
- Use firewall rules to prevent clients reaching Ollama/local model servers or database files directly.
- Use BitLocker on Windows Server or LUKS on Linux for the data volume in addition to HIVE MIND application encryption.
- Run the HIVE MIND service under a dedicated non-admin OS account.
- Back up `storage/` using the built-in encrypted backup or an enterprise backup system with equivalent controls.

## Self-check
Run:

```
.venv\Scripts\python.exe selfcheck.py
```

It validates Python compilation, encryption round-trip, local-LLM destination safety, bind configuration, and data location.

## Important scope boundary
This build is production-oriented application code, but software cannot truthfully be called secure merely because code was reviewed once. Before handling regulated or highly sensitive production data, run your organization's vulnerability scanner/SAST/dependency audit, deploy malware scanning, test restore procedures, verify OS/network ACLs, and conduct an independent penetration test appropriate to your environment.
