$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$payload = Join-Path $here 'payload'
$root = Join-Path $env:LOCALAPPDATA 'HiveMind'
$app = Join-Path $root 'app'
$data = Join-Path $root 'data'
$backup = Join-Path $root ('upgrade-backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
$log = Join-Path $root 'install.log'
$model = 'llama3.2:3b'

function Stop-NexusProcesses {
    param([string]$AppPath,[string]$RootPath)
    Write-Host 'Stopping running HIVE MIND processes before upgrade...'
    $ids = New-Object System.Collections.Generic.HashSet[int]
    try {
        $procs = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue
        foreach ($p in $procs) {
            $cmd = [string]$p.CommandLine
            $exe = [string]$p.ExecutablePath
            if (($exe -and $exe.StartsWith($AppPath,[System.StringComparison]::OrdinalIgnoreCase)) -or
                ($cmd -and ($cmd -like "*$AppPath*run.py*" -or $cmd -like "*$RootPath*Start HIVE MIND.bat*"))) {
                [void]$ids.Add([int]$p.ProcessId)
            }
        }
    } catch {}
    try {
        $listeners = Get-NetTCPConnection -LocalPort 8787 -State Listen -ErrorAction SilentlyContinue
        foreach ($listener in $listeners) {
            $pidToCheck = [int]$listener.OwningProcess
            $proc = Get-CimInstance Win32_Process -Filter "ProcessId=$pidToCheck" -ErrorAction SilentlyContinue
            if ($proc) {
                $cmd=[string]$proc.CommandLine; $exe=[string]$proc.ExecutablePath
                if (($exe -and $exe.StartsWith($AppPath,[System.StringComparison]::OrdinalIgnoreCase)) -or ($cmd -match 'HIVE MINDMemory|run\.py')) {
                    [void]$ids.Add($pidToCheck)
                } else {
                    throw "Port 8787 is in use by another application (PID $pidToCheck). Close it and run the installer again."
                }
            }
        }
    } catch {
        if ($_.Exception.Message -like 'Port 8787 is in use*') { throw }
    }
    foreach ($id in $ids) {
        if ($id -eq $PID) { continue }
        Write-Host "Stopping HIVE MIND process PID $id..."
        & taskkill.exe /PID $id /T /F *> $null
    }
    Start-Sleep -Seconds 2
}

function Find-Ollama {
    $cmd = Get-Command ollama.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $candidates = @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'),
        (Join-Path $env:LOCALAPPDATA 'Ollama\ollama.exe'),
        (Join-Path $env:ProgramFiles 'Ollama\ollama.exe')
    )
    foreach ($c in $candidates) { if (Test-Path $c) { return $c } }
    return $null
}

function Test-OllamaReady {
    try {
        $r = Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -Method Get -TimeoutSec 2
        return $true
    } catch { return $false }
}

function Stop-NonLoopbackOllama {
    try {
        $listeners = Get-NetTCPConnection -LocalPort 11434 -State Listen -ErrorAction SilentlyContinue
        foreach ($listener in $listeners) {
            $addr=[string]$listener.LocalAddress
            if ($addr -notin @('127.0.0.1','::1')) {
                $owner=[int]$listener.OwningProcess
                Write-Host "Restarting local AI because port 11434 was exposed on $addr..."
                & taskkill.exe /PID $owner /T /F *> $null
                Start-Sleep -Seconds 1
            }
        }
    } catch {}
}

function Start-OllamaLocal {
    param([string]$OllamaExe)
    Stop-NonLoopbackOllama
    if (Test-OllamaReady) { return $true }
    $env:OLLAMA_HOST = '127.0.0.1:11434'
    Start-Process -FilePath $OllamaExe -ArgumentList 'serve' -WindowStyle Hidden | Out-Null
    for ($i=0; $i -lt 30; $i++) {
        Start-Sleep -Milliseconds 500
        if (Test-OllamaReady) { return $true }
    }
    return $false
}

function Ensure-LocalAI {
    param([string]$ModelName)
    Write-Host ''
    Write-Host 'Configuring local Meta Llama 3.2 3B AI...'
    $ollama = Find-Ollama
    if (-not $ollama) {
        $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
        if ($winget) {
            Write-Host 'Installing local AI runtime with Windows Package Manager...'
            & winget.exe install --id Ollama.Ollama -e --scope user --silent --accept-package-agreements --accept-source-agreements --disable-interactivity
            Start-Sleep -Seconds 2
            $ollama = Find-Ollama
        }
    }
    if (-not $ollama) {
        Write-Warning 'Ollama could not be installed automatically. HIVE MIND is installed, but Local AI will remain offline until Ollama is installed.'
        return $false
    }
    if (-not (Start-OllamaLocal -OllamaExe $ollama)) {
        Write-Warning 'The local AI runtime is installed but did not start on 127.0.0.1:11434.'
        return $false
    }
    $present = $false
    try {
        $tags = Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -Method Get -TimeoutSec 5
        foreach ($m in $tags.models) {
            $n = [string]($m.name)
            if ($n -eq $ModelName -or ($ModelName -eq 'llama3.2:3b' -and $n -eq 'llama3.2:latest')) { $present=$true; break }
        }
    } catch {}
    if (-not $present) {
        Write-Host 'Downloading Meta Llama 3.2 3B for offline use...'
        & $ollama pull $ModelName
        if ($LASTEXITCODE -ne 0) {
            Write-Warning 'Llama 3.2 3B could not be downloaded. HIVE MIND is installed; run Local AI Setup later when package access is available.'
            return $false
        }
    }
    Write-Host 'Local AI ready: Meta Llama 3.2 3B.'
    return $true
}

New-Item -ItemType Directory -Force -Path $root | Out-Null
Start-Transcript -Path $log -Append | Out-Null
Write-Host ''
Write-Host '============================================================'
Write-Host ' HIVE MIND 2.0.3 - FULL WINDOWS INSTALLER'
Write-Host ' Meta Llama 3.2 3B Local AI'
Write-Host '============================================================'
Write-Host ''

if (!(Test-Path $payload)) { throw "Installer payload is missing: $payload" }
Stop-NexusProcesses -AppPath $app -RootPath $root

New-Item -ItemType Directory -Force -Path $data | Out-Null
# Automatic migration from the prior NEXUS Memory installed data directory.
$oldInstalledData = Join-Path $env:LOCALAPPDATA 'NEXUSMemory\data'
if (!(Test-Path (Join-Path $data 'nexus.db')) -and (Test-Path (Join-Path $oldInstalledData 'nexus.db'))) {
    Write-Host 'Migrating existing NEXUS Memory data into HIVE MIND...'
    Copy-Item -Path (Join-Path $oldInstalledData '*') -Destination $data -Recurse -Force
}

# Save only replaceable application configuration for rollback diagnostics. Persistent data is separate.
if (Test-Path $app) {
    New-Item -ItemType Directory -Force -Path $backup | Out-Null
    foreach ($f in @('.env','VERSION.txt')) {
        $src=Join-Path $app $f
        if (Test-Path $src) { Copy-Item -Force $src $backup }
    }
}

# First-install migration from earlier source-bundle storage.
$db = Join-Path $data 'nexus.db'
if (!(Test-Path $db)) {
    $roots = @((Join-Path $env:USERPROFILE 'Downloads'), (Join-Path $env:USERPROFILE 'Desktop'), (Join-Path $env:USERPROFILE 'Documents')) | Where-Object { Test-Path $_ }
    $candidates = @()
    foreach ($r in $roots) {
        try {
            $candidates += Get-ChildItem -Path $r -Filter nexus.db -File -Recurse -ErrorAction SilentlyContinue |
                Where-Object { $_.FullName -match '[\\/]storage[\\/]nexus\.db$' -and $_.FullName -notlike "$root*" } |
                Sort-Object LastWriteTime -Descending
        } catch {}
    }
    if ($candidates.Count -gt 0) {
        $oldDb = $candidates[0]
        $oldStorage = Split-Path -Parent $oldDb.FullName
        Write-Host "Found previous HIVE MIND data at: $oldStorage"
        $ans = Read-Host 'Migrate this existing data into the permanent installation? [Y/n]'
        if ([string]::IsNullOrWhiteSpace($ans) -or $ans -match '^[Yy]') {
            Write-Host 'Migrating existing HIVE MIND storage...'
            Copy-Item -Path (Join-Path $oldStorage '*') -Destination $data -Recurse -Force
        }
    }
}

# Replace application code only. Retry native-module release and use a stale-folder fallback.
if (Test-Path $app) {
    try { attrib.exe -R -S -H "$app\*" /S /D *> $null } catch {}
    $removed=$false
    for ($i=0; $i -lt 12 -and -not $removed; $i++) {
        try { Remove-Item -Recurse -Force $app -ErrorAction Stop; $removed=$true }
        catch { Start-Sleep -Milliseconds 750 }
    }
    if (-not $removed) {
        $stale = Join-Path $root ('app-stale-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
        try { Move-Item -Force $app $stale; $removed=$true } catch {}
    }
    if (-not $removed) { throw 'Windows still has a HIVE MIND native module open. The installer stopped known HIVE MIND processes, but another security/AV process may still hold the file. Persistent data was not changed.' }
}
New-Item -ItemType Directory -Force -Path $app | Out-Null
Copy-Item -Path (Join-Path $payload '*') -Destination $app -Recurse -Force

# Installation-specific environment. Local model endpoint is loopback-only.
$envFile = Join-Path $app '.env'
$dataPosix = $data -replace '\\','/'
@"
HIVE_DATA_DIR=$dataPosix
HIVE_HOST=127.0.0.1
HIVE_PORT=8787
HIVE_ALLOWED_HOSTS=127.0.0.1,localhost
HIVE_MAX_UPLOAD_MB=20480
HIVE_MAX_FILES_PER_UPLOAD=50
HIVE_LOCAL_LLM_URL=http://127.0.0.1:11434/api/chat
HIVE_LOCAL_LLM_MODEL=llama3.2:3b
HIVE_ENABLE_LLM=true
HIVE_REQUIRE_MALWARE_SCANNER=false
HIVE_COOKIE_SECURE=false
"@ | Set-Content -Path $envFile -Encoding ASCII

# Resolve Python 3.12 then 3.11. Never use bare system pip.
$pyCmd = $null
try { & py -3.12 -c "import sys" *> $null; if ($LASTEXITCODE -eq 0) { $pyCmd = @('py','-3.12') } } catch {}
if (-not $pyCmd) { try { & py -3.11 -c "import sys" *> $null; if ($LASTEXITCODE -eq 0) { $pyCmd = @('py','-3.11') } } catch {} }
if (-not $pyCmd) { try { & python -c "import sys; assert sys.version_info >= (3,11)" *> $null; if ($LASTEXITCODE -eq 0) { $pyCmd = @('python') } } catch {} }
if (-not $pyCmd) { throw 'Python 3.11 or 3.12 is required. Install 64-bit Python and run this installer again.' }

$venv = Join-Path $app '.venv'
Write-Host 'Creating isolated HIVE MIND Python environment...'
if ($pyCmd.Count -eq 2) { & $pyCmd[0] $pyCmd[1] -m venv $venv } else { & $pyCmd[0] -m venv $venv }
if ($LASTEXITCODE -ne 0) { throw 'Unable to create the HIVE MIND Python environment.' }
$vpy = Join-Path $venv 'Scripts\python.exe'

Write-Host 'Installing HIVE MIND dependencies, including Outlook PST/MSG support...'
& $vpy -m pip install --disable-pip-version-check -r (Join-Path $app 'backend\requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Check network/internal PyPI access and install.log.' }

Write-Host 'Running dependency self-check...'
& $vpy (Join-Path $app 'installer_selfcheck.py')
if ($LASTEXITCODE -ne 0) { throw 'HIVE MIND dependency self-check failed.' }
Write-Host 'Running application source self-check...'
& $vpy (Join-Path $app 'selfcheck.py')
if ($LASTEXITCODE -ne 0) { throw 'HIVE MIND application self-check failed.' }

$aiReady = Ensure-LocalAI -ModelName $model

# Stable local-AI helper outside replaceable app directory.
$aiPs1 = Join-Path $root 'Start Local AI.ps1'
@'
$ErrorActionPreference='SilentlyContinue'
$ollama=(Get-Command ollama.exe -ErrorAction SilentlyContinue).Source
if (-not $ollama) {
  $candidates=@((Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'),(Join-Path $env:LOCALAPPDATA 'Ollama\ollama.exe'),(Join-Path $env:ProgramFiles 'Ollama\ollama.exe'))
  foreach($c in $candidates){if(Test-Path $c){$ollama=$c;break}}
}
if (-not $ollama){exit 2}
try {
  $ls=Get-NetTCPConnection -LocalPort 11434 -State Listen -ErrorAction SilentlyContinue
  foreach($l in $ls){if(([string]$l.LocalAddress) -notin @('127.0.0.1','::1')){taskkill.exe /PID ([int]$l.OwningProcess) /T /F *> $null;Start-Sleep 1}}
}catch{}
try { Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 2 | Out-Null; exit 0 } catch {}
$env:OLLAMA_HOST='127.0.0.1:11434'
Start-Process -FilePath $ollama -ArgumentList 'serve' -WindowStyle Hidden | Out-Null
for($i=0;$i -lt 20;$i++){Start-Sleep -Milliseconds 500;try{Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 2|Out-Null;exit 0}catch{}}
exit 3
'@ | Set-Content -Path $aiPs1 -Encoding UTF8

$startBat = Join-Path $root 'Start HIVE MIND.bat'
@"
@echo off
setlocal
cd /d "$app"
title HIVE MIND
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$aiPs1" >nul 2>&1
if not exist ".venv\Scripts\python.exe" (
  echo HIVE MIND environment is missing. Run Repair HIVE MIND.bat.
  pause
  exit /b 1
)
start "" http://127.0.0.1:8787
".venv\Scripts\python.exe" run.py
"@ | Set-Content -Path $startBat -Encoding ASCII

$repairBat = Join-Path $root 'Repair HIVE MIND.bat'
@"
@echo off
setlocal
title Repair HIVE MIND
echo Stopping HIVE MIND before repair...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":8787" ^| findstr "LISTENING"') do taskkill /PID %%a /T /F >nul 2>&1
cd /d "$app"
echo Rebuilding HIVE MIND application environment. Persistent data will not be deleted.
if exist ".venv" rmdir /s /q ".venv"
set "PYEXE="
where py ^>nul 2^>^&1 ^&^& ^(py -3.12 -c "import sys" ^>nul 2^>^&1 ^&^& set "PYEXE=py -3.12"^)
if not defined PYEXE where py ^>nul 2^>^&1 ^&^& ^(py -3.11 -c "import sys" ^>nul 2^>^&1 ^&^& set "PYEXE=py -3.11"^)
if not defined PYEXE where python ^>nul 2^>^&1 ^&^& set "PYEXE=python"
if not defined PYEXE ^(echo Python 3.11 or 3.12 not found.^& pause ^& exit /b 1^)
%PYEXE% -m venv .venv || goto :fail
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r backend\requirements.txt || goto :fail
".venv\Scripts\python.exe" installer_selfcheck.py || goto :fail
".venv\Scripts\python.exe" selfcheck.py || goto :fail
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$aiPs1" >nul 2>&1
echo Repair complete. No persistent data was deleted.
pause
exit /b 0
:fail
echo Repair failed. Persistent data was not deleted.
pause
exit /b 1
"@ | Set-Content -Path $repairBat -Encoding ASCII

$setupAiBat = Join-Path $root 'Setup Local AI - Llama 3.2 3B.bat'
@"
@echo off
setlocal
title HIVE MIND Local AI Setup
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "& { `$o=(Get-Command ollama.exe -ErrorAction SilentlyContinue).Source; if(-not `$o){`$c=@((Join-Path `$env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'),(Join-Path `$env:LOCALAPPDATA 'Ollama\ollama.exe'));foreach(`$x in `$c){if(Test-Path `$x){`$o=`$x;break}}}; if(-not `$o){Write-Host 'Ollama is not installed. Re-run the full HIVE MIND installer while package access is available.'; exit 2}; `$env:OLLAMA_HOST='127.0.0.1:11434'; try{Invoke-RestMethod http://127.0.0.1:11434/api/tags -TimeoutSec 2|Out-Null}catch{Start-Process `$o -ArgumentList 'serve' -WindowStyle Hidden;Start-Sleep 3}; & `$o pull llama3.2:3b }"
echo.
echo Local AI setup finished. HIVE MIND uses Meta Llama 3.2 3B entirely through localhost.
pause
"@ | Set-Content -Path $setupAiBat -Encoding ASCII

$uninstallBat = Join-Path $root 'Uninstall HIVE MIND App - KEEP DATA.bat'
@"
@echo off
setlocal
choice /M "Remove HIVE MIND application files and shortcuts but KEEP all persistent data"
if errorlevel 2 exit /b 0
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":8787" ^| findstr "LISTENING"') do taskkill /PID %%a /T /F >nul 2>&1
if exist "$app" rmdir /s /q "$app"
del /q "%USERPROFILE%\Desktop\HIVE MIND.lnk" >nul 2>&1
echo HIVE MIND application removed. Data remains at "$data".
pause
"@ | Set-Content -Path $uninstallBat -Encoding ASCII

# Desktop and Start Menu shortcuts.
$ws = New-Object -ComObject WScript.Shell
$desktopLink = Join-Path ([Environment]::GetFolderPath('Desktop')) 'HIVE MIND.lnk'
$sc = $ws.CreateShortcut($desktopLink)
$sc.TargetPath = $startBat
$sc.WorkingDirectory = $root
$sc.Description = 'HIVE MIND - Secure Offline Knowledge Preservation'; $sc.IconLocation = (Join-Path $app 'frontend\assets\hive-mind.ico')
$sc.Save()
$programs = [Environment]::GetFolderPath('Programs')
$menuDir = Join-Path $programs 'HIVE MIND'
New-Item -ItemType Directory -Force -Path $menuDir | Out-Null
foreach ($entry in @(
    @('HIVE MIND.lnk',$startBat),
    @('Repair HIVE MIND.lnk',$repairBat),
    @('Setup Local AI - Llama 3.2 3B.lnk',$setupAiBat),
    @('Uninstall HIVE MIND - Keep Data.lnk',$uninstallBat))) {
    $link = Join-Path $menuDir $entry[0]
    $s = $ws.CreateShortcut($link); $s.TargetPath=$entry[1]; $s.WorkingDirectory=$root; $s.Save()
}

Write-Host ''
Write-Host 'HIVE MIND 2.0.3 INSTALLATION COMPLETE.'
Write-Host "Application: $app"
Write-Host "Persistent data: $data"
Write-Host "Local AI model: Meta Llama 3.2 3B"
if ($aiReady) { Write-Host 'Local AI status: READY' } else { Write-Host 'Local AI status: NEEDS SETUP' }
Write-Host "Install log: $log"
Write-Host ''
$launch = Read-Host 'Launch HIVE MIND now? [Y/n]'
if ([string]::IsNullOrWhiteSpace($launch) -or $launch -match '^[Yy]') { Start-Process -FilePath $startBat }
Stop-Transcript | Out-Null
