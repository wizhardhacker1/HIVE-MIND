#!/usr/bin/env bash
set -euo pipefail

APP_NAME="HIVE MIND"
VERSION="2.0.15"
MODEL="llama3.2:3b"
HOST="127.0.0.1"
PORT="8787"
OLLAMA_PORT="11434"

say(){ printf '\n[%s] %s\n' "$APP_NAME" "$*"; }
warn(){ printf '\n[%s] WARNING: %s\n' "$APP_NAME" "$*" >&2; }
fail(){ printf '\n[%s] ERROR: %s\n' "$APP_NAME" "$*" >&2; exit 1; }
has(){ command -v "$1" >/dev/null 2>&1; }

# RHEL-family validation.
if [ -r /etc/os-release ]; then
  . /etc/os-release
  os_blob="${ID:-} ${ID_LIKE:-}"
else
  os_blob=""
fi
case " $os_blob " in
  *" rhel "*|*" fedora "*|*" centos "*|*|*" rocky "*|*|*" almalinux "*|*|*" ol "*) ;;
  *) warn "This installer is intended for RHEL/Rocky/Alma/CentOS Stream/Oracle Linux/Fedora-family systems." ;;
esac

# Keep the application owned by the desktop user even when launched with sudo.
# Package installation is elevated separately when required.
if [ "${EUID:-$(id -u)}" -eq 0 ] && [ -n "${SUDO_USER:-}" ] && [ "${SUDO_USER}" != "root" ]; then
  TARGET_USER="$SUDO_USER"
  TARGET_HOME="$(getent passwd "$TARGET_USER" 2>/dev/null | cut -d: -f6)"
  [ -n "$TARGET_HOME" ] || TARGET_HOME="/home/$TARGET_USER"
  say "sudo detected. Installing HIVE MIND for $TARGET_USER, not under /root."
  exec sudo -u "$TARGET_USER" -H env HIVE_RHEL_ALLOW_SUDO=1 HOME="$TARGET_HOME" bash "$0" "$@"
fi

HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$HERE/payload"
[ -d "$PAYLOAD" ] || fail "Installer payload was not found. Extract the complete ZIP before running this script."

DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
CONFIG_HOME="${XDG_CONFIG_HOME:-$HOME/.config}"
STATE_HOME="${XDG_STATE_HOME:-$HOME/.local/state}"
APP_ROOT="$DATA_HOME/HiveMind"
APP_DIR="$APP_ROOT/app"
DATA_DIR="$APP_ROOT/data"
CONFIG_DIR="$CONFIG_HOME/HiveMind"
STATE_DIR="$STATE_HOME/HiveMind"
BIN_DIR="$HOME/.local/bin"
DESKTOP_APPS="$DATA_HOME/applications"
AUTOSTART_DIR="$CONFIG_HOME/autostart"
DESKTOP_DIR="${XDG_DESKTOP_DIR:-$HOME/Desktop}"

if has sudo; then
  ELEVATE=(sudo)
elif [ "${EUID:-$(id -u)}" -eq 0 ]; then
  ELEVATE=()
else
  fail "sudo is required to install missing RHEL packages. Install sudo or run the installer from an administrator account."
fi

PKG=""
if has dnf; then PKG="dnf"; elif has yum; then PKG="yum"; else fail "dnf/yum was not found. Use INSTALL_HIVE_MIND.sh for non-RHEL Linux systems."; fi
pkg_install(){ "${ELEVATE[@]}" "$PKG" install -y "$@"; }

mkdir -p "$APP_ROOT" "$DATA_DIR" "$CONFIG_DIR" "$STATE_DIR" "$BIN_DIR" "$DESKTOP_APPS"
say "Installing HIVE MIND $VERSION for RHEL-family Linux..."

# Base tools used by the installer/launcher. These package names are stable across
# supported RHEL-family releases. Fail only for tools HIVE MIND actually needs.
missing=()
has curl || missing+=(curl)
has tar || missing+=(tar)
has awk || missing+=(gawk)
if [ ${#missing[@]} -gt 0 ]; then
  say "Installing required RHEL utilities: ${missing[*]}"
  pkg_install "${missing[@]}"
fi

python_compatible(){
  "$1" - <<'PY' >/dev/null 2>&1
import sys
raise SystemExit(0 if (3,10) <= sys.version_info[:2] < (3,14) else 1)
PY
}
choose_python(){
  local candidate
  for candidate in python3.13 python3.12 python3.11 python3.10 python3; do
    if has "$candidate" && python_compatible "$candidate"; then printf '%s\n' "$candidate"; return 0; fi
  done
  return 1
}

PYTHON_BIN="$(choose_python || true)"
if [ -z "$PYTHON_BIN" ]; then
  say "Installing a HIVE MIND-compatible Python for RHEL..."
  # RHEL 9 commonly provides Python 3.11/3.12 as additional interpreters;
  # newer RHEL-family releases may provide 3.13. Try newest supported first.
  for pkg in python3.13 python3.12 python3.11 python3.10; do
    if pkg_install "$pkg" "${pkg}-pip" >/dev/null 2>&1; then
      PYTHON_BIN="$(choose_python || true)"
      [ -n "$PYTHON_BIN" ] && break
    fi
    if pkg_install "$pkg" >/dev/null 2>&1; then
      PYTHON_BIN="$(choose_python || true)"
      [ -n "$PYTHON_BIN" ] && break
    fi
  done
fi
[ -n "$PYTHON_BIN" ] || fail "No supported Python was available from enabled RHEL repositories. HIVE MIND requires CPython 3.10-3.13. Enable the appropriate Red Hat repositories/AppStream for Python 3.11 or 3.12, then rerun this installer."
PYTHON_VERSION="$($PYTHON_BIN -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")')"
say "Using $PYTHON_BIN ($PYTHON_VERSION)."

# Verify actual environment creation. Some minimal RHEL images omit pip/ensurepip.
probe="$(mktemp -d)"
if ! "$PYTHON_BIN" -m venv "$probe/test" >/dev/null 2>"$probe/error"; then
  say "Adding Python virtual-environment support for $PYTHON_BIN..."
  py_mm="$($PYTHON_BIN -c 'import sys; print(f"python{sys.version_info.major}.{sys.version_info.minor}")')"
  pkg_install "${py_mm}-pip" >/dev/null 2>&1 || pkg_install python3-pip >/dev/null 2>&1 || true
  rm -rf "$probe/test"
  "$PYTHON_BIN" -m ensurepip --upgrade >/dev/null 2>&1 || true
  if ! "$PYTHON_BIN" -m venv "$probe/test" >/dev/null 2>"$probe/error"; then
    "$PYTHON_BIN" -m pip install --user --disable-pip-version-check virtualenv >/dev/null 2>&1 || true
    rm -rf "$probe/test"
    if ! "$PYTHON_BIN" -m virtualenv "$probe/test" >/dev/null 2>"$probe/error"; then
      detail="$(tail -n 10 "$probe/error" 2>/dev/null || true)"
      rm -rf "$probe"
      fail "Could not create a Python virtual environment with $PYTHON_BIN. $detail"
    fi
  fi
fi
rm -rf "$probe"

# Stop only a known HIVE MIND process before replacing application code.
if [ -f "$STATE_DIR/hive-mind.pid" ]; then
  oldpid="$(cat "$STATE_DIR/hive-mind.pid" 2>/dev/null || true)"
  if [ -n "$oldpid" ] && kill -0 "$oldpid" 2>/dev/null; then
    cmd="$(ps -p "$oldpid" -o args= 2>/dev/null || true)"
    if [[ "$cmd" == *"$APP_DIR"*"run.py"* ]]; then
      say "Stopping the existing HIVE MIND service..."
      kill "$oldpid" 2>/dev/null || true
      for _ in {1..20}; do kill -0 "$oldpid" 2>/dev/null || break; sleep 0.25; done
    fi
  fi
fi

say "Installing application files into $APP_DIR"
tmp="$APP_ROOT/.app-new-$$"
rm -rf "$tmp"; mkdir -p "$tmp"; cp -a "$PAYLOAD/." "$tmp/"
rm -rf "$APP_DIR.old"
[ -d "$APP_DIR" ] && mv "$APP_DIR" "$APP_DIR.old"
mv "$tmp" "$APP_DIR"
rm -rf "$APP_DIR.old"

cat > "$APP_DIR/.env" <<ENV
HIVE_DATA_DIR=$DATA_DIR
HIVE_HOST=$HOST
HIVE_PORT=$PORT
HIVE_ALLOWED_HOSTS=127.0.0.1,localhost
HIVE_MAX_UPLOAD_MB=20480
HIVE_MAX_FILES_PER_UPLOAD=50
HIVE_LOCAL_LLM_URL=http://127.0.0.1:$OLLAMA_PORT/api/chat
HIVE_LOCAL_LLM_MODEL=$MODEL
HIVE_ENABLE_LLM=true
HIVE_REQUIRE_MALWARE_SCANNER=false
HIVE_COOKIE_SECURE=false
ENV
chmod 600 "$APP_DIR/.env"

say "Preparing the private Python environment..."
rm -rf "$APP_DIR/.venv"
if ! "$PYTHON_BIN" -m venv "$APP_DIR/.venv" >/dev/null 2>&1; then
  "$PYTHON_BIN" -m virtualenv "$APP_DIR/.venv"
fi
printf '%s\n' "$PYTHON_BIN" > "$APP_DIR/.python-bin"
"$APP_DIR/.venv/bin/python" -m pip install --disable-pip-version-check --upgrade pip setuptools wheel >/dev/null
"$APP_DIR/.venv/bin/python" -m pip install --disable-pip-version-check --prefer-binary -r "$APP_DIR/backend/requirements.txt"

# OCR is optional, but install Tesseract when available so image/document OCR works immediately.
if ! has tesseract; then
  pkg_install tesseract >/dev/null 2>&1 || warn "Tesseract OCR was not available from enabled repositories. Core HIVE MIND will still work."
fi

# Ollama stays loopback-only. The official installer handles the appropriate RPM/system files.
if ! has ollama; then
  say "Ollama was not found. Attempting the official Linux installation..."
  if curl -fsS --connect-timeout 5 https://ollama.com/ >/dev/null 2>&1; then
    if curl -fsSL https://ollama.com/install.sh | sh; then :; else warn "Ollama installation did not complete. HIVE MIND can still run without General AI until Ollama is installed."; fi
  else
    warn "Offline installation detected. Ollama was not installed; HIVE MIND will still start and can use vault search without local AI."
  fi
fi

# One-click launcher. No firewall opening is required because HIVE MIND and Ollama
# bind only to 127.0.0.1. SELinux remains enabled/enforcing; this installer does not alter policy.
cat > "$BIN_DIR/hive-mind" <<'LAUNCHER'
#!/usr/bin/env bash
set -u
HOST="127.0.0.1"; PORT="8787"; OLLAMA_PORT="11434"; MODEL="llama3.2:3b"
DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"; STATE_HOME="${XDG_STATE_HOME:-$HOME/.local/state}"
APP_DIR="$DATA_HOME/HiveMind/app"; STATE_DIR="$STATE_HOME/HiveMind"; PIDFILE="$STATE_DIR/hive-mind.pid"; LOG="$STATE_DIR/quick-start.log"
NO_BROWSER=0; [ "${1:-}" = "--background" ] && NO_BROWSER=1
mkdir -p "$STATE_DIR"; exec >>"$LOG" 2>&1
printf '\n=== HIVE MIND Quick Start %s ===\n' "$(date -Is)"
notify(){ command -v notify-send >/dev/null 2>&1 && notify-send "HIVE MIND" "$1" >/dev/null 2>&1 || true; }
url_ok(){ curl -fsS --max-time 2 "$1" >/dev/null 2>&1; }
open_browser(){ [ "$NO_BROWSER" -eq 1 ] && return 0; command -v xdg-open >/dev/null 2>&1 && xdg-open "http://$HOST:$PORT" >/dev/null 2>&1 & }
[ -x "$APP_DIR/.venv/bin/python" ] || { notify "Installation is incomplete. Run the RHEL installer again."; exit 2; }
if ! url_ok "http://$HOST:$OLLAMA_PORT/api/tags" && command -v ollama >/dev/null 2>&1; then
  export OLLAMA_HOST="$HOST:$OLLAMA_PORT"; nohup ollama serve >>"$STATE_DIR/ollama.log" 2>&1 &
  for _ in {1..40}; do url_ok "http://$HOST:$OLLAMA_PORT/api/tags" && break; sleep 0.5; done
fi
if url_ok "http://$HOST:$OLLAMA_PORT/api/tags" && command -v ollama >/dev/null 2>&1; then
  if ! ollama list 2>/dev/null | awk 'NR>1{print $1}' | grep -Fxq "$MODEL"; then
    notify "Preparing local AI model. First start may take several minutes."; ollama pull "$MODEL" >>"$STATE_DIR/ollama-model.log" 2>&1 || true
  fi
fi
if url_ok "http://$HOST:$PORT/api/health"; then open_browser; exit 0; fi
if [ -f "$PIDFILE" ]; then
  pid="$(cat "$PIDFILE" 2>/dev/null || true)"
  if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
    cmd="$(ps -p "$pid" -o args= 2>/dev/null || true)"
    if [[ "$cmd" == *"$APP_DIR"*"run.py"* ]]; then
      for _ in {1..60}; do url_ok "http://$HOST:$PORT/api/health" && { open_browser; exit 0; }; sleep 0.5; done
      notify "HIVE MIND is running but did not become ready. See $LOG"; exit 3
    fi
  fi
fi
cd "$APP_DIR" || exit 4
nohup "$APP_DIR/.venv/bin/python" "$APP_DIR/run.py" >>"$STATE_DIR/server.log" 2>&1 &
pid=$!; printf '%s\n' "$pid" > "$PIDFILE"
for _ in {1..80}; do
  if url_ok "http://$HOST:$PORT/api/health"; then open_browser; exit 0; fi
  kill -0 "$pid" 2>/dev/null || break; sleep 0.5
done
notify "HIVE MIND could not start. See $STATE_DIR/server.log"; exit 5
LAUNCHER
chmod 755 "$BIN_DIR/hive-mind"

cat > "$BIN_DIR/hive-mind-stop" <<'STOPPER'
#!/usr/bin/env bash
STATE_HOME="${XDG_STATE_HOME:-$HOME/.local/state}"; PIDFILE="$STATE_HOME/HiveMind/hive-mind.pid"
if [ -f "$PIDFILE" ]; then pid="$(cat "$PIDFILE" 2>/dev/null || true)"; [ -n "$pid" ] && kill "$pid" 2>/dev/null || true; rm -f "$PIDFILE"; fi
STOPPER
chmod 755 "$BIN_DIR/hive-mind-stop"

ICON="$APP_DIR/frontend/assets/hive-mind-logo.png"
cat > "$DESKTOP_APPS/hive-mind.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=HIVE MIND
Comment=Secure offline organizational knowledge system
Exec=$BIN_DIR/hive-mind
Icon=$ICON
Terminal=false
Categories=Office;Utility;
StartupNotify=true
DESKTOP
chmod 644 "$DESKTOP_APPS/hive-mind.desktop"

if [ -d "$DESKTOP_DIR" ]; then
  cp "$DESKTOP_APPS/hive-mind.desktop" "$DESKTOP_DIR/HIVE MIND.desktop" 2>/dev/null || true
  chmod +x "$DESKTOP_DIR/HIVE MIND.desktop" 2>/dev/null || true
  command -v gio >/dev/null 2>&1 && gio set "$DESKTOP_DIR/HIVE MIND.desktop" metadata::trusted true >/dev/null 2>&1 || true
fi
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$DESKTOP_APPS" >/dev/null 2>&1 || true

if has ollama; then
  if ! curl -fsS --max-time 2 "http://$HOST:$OLLAMA_PORT/api/tags" >/dev/null 2>&1; then
    export OLLAMA_HOST="$HOST:$OLLAMA_PORT"; nohup ollama serve >>"$STATE_DIR/ollama.log" 2>&1 &
    for _ in {1..30}; do curl -fsS --max-time 2 "http://$HOST:$OLLAMA_PORT/api/tags" >/dev/null 2>&1 && break; sleep 0.5; done
  fi
  if curl -fsS --max-time 2 "http://$HOST:$OLLAMA_PORT/api/tags" >/dev/null 2>&1 && ! ollama list 2>/dev/null | awk 'NR>1{print $1}' | grep -Fxq "$MODEL"; then
    say "Downloading the local $MODEL model..."; ollama pull "$MODEL" || warn "Model download failed. Quick Start will retry later."
  fi
fi

printf '\nStart HIVE MIND automatically when you sign in? [y/N] '
read -r startup || startup=""
if [[ "$startup" =~ ^[Yy]$ ]]; then
  mkdir -p "$AUTOSTART_DIR"
  cat > "$AUTOSTART_DIR/hive-mind.desktop" <<AUTO
[Desktop Entry]
Type=Application
Name=HIVE MIND
Exec=$BIN_DIR/hive-mind --background
Icon=$ICON
Terminal=false
X-GNOME-Autostart-enabled=true
AUTO
  chmod 644 "$AUTOSTART_DIR/hive-mind.desktop"
else
  rm -f "$AUTOSTART_DIR/hive-mind.desktop" 2>/dev/null || true
fi

say "RHEL installation complete."
echo "Application: $APP_DIR"
echo "Persistent data: $DATA_DIR"
echo "Launcher: $BIN_DIR/hive-mind"
echo "SELinux: unchanged"
echo "Network bind: 127.0.0.1 only (no firewalld port required)"
printf '\nLaunch HIVE MIND now? [Y/n] '
read -r launch || launch=""
if [ -z "$launch" ] || [[ "$launch" =~ ^[Yy]$ ]]; then "$BIN_DIR/hive-mind" >/dev/null 2>&1 & fi
