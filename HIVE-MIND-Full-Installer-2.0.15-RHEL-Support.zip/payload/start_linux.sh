#!/usr/bin/env bash
set -euo pipefail
if [ -x "$HOME/.local/bin/hive-mind" ]; then exec "$HOME/.local/bin/hive-mind" "$@"; fi
cd "$(dirname "$0")"

python_compatible(){
  "$1" - <<'PY' >/dev/null 2>&1
import sys
raise SystemExit(0 if (3,10) <= sys.version_info[:2] < (3,14) else 1)
PY
}

PYTHON_BIN=""
for candidate in python3.13 python3.12 python3.11 python3.10 python3; do
  if command -v "$candidate" >/dev/null 2>&1 && python_compatible "$candidate"; then PYTHON_BIN="$candidate"; break; fi
done
[ -n "$PYTHON_BIN" ] || { echo "HIVE MIND requires Python 3.10 through 3.13. Run INSTALL_HIVE_MIND.sh to configure a compatible Python." >&2; exit 1; }

if [ ! -x .venv/bin/python ] || ! python_compatible .venv/bin/python; then
  rm -rf .venv
  "$PYTHON_BIN" -m venv .venv
fi
.venv/bin/python -c 'import fastapi,uvicorn,sqlalchemy,cryptography,argon2,fitz,docx,openpyxl,pptx,bs4,numpy,httpx' >/dev/null 2>&1 || .venv/bin/python -m pip install --disable-pip-version-check --prefer-binary -r backend/requirements.txt
[ -f .env ] || cp .env.example .env
mkdir -p storage
exec .venv/bin/python run.py
