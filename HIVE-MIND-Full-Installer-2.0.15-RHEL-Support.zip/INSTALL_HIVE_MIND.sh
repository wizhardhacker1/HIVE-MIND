#!/usr/bin/env bash
set -euo pipefail

APP_NAME="HIVE MIND"
VERSION="2.0.15"
MODEL="llama3.2:3b"
HOST="127.0.0.1"
PORT="8787"
OLLAMA_PORT="11434"

# If the installer was started with sudo from a desktop user account, immediately
# return to that user for the application install. The script will elevate only
# the package-manager commands that actually require root. This prevents a
# per-user HIVE MIND install from accidentally landing under /root/.local.
if [ "${EUID:-$(id -u)}" -eq 0 ] && [ -n "${SUDO_USER:-}" ] && [ "${SUDO_USER}" != "root" ]; then
  TARGET_USER="$SUDO_USER"
  TARGET_HOME="$(getent passwd "$TARGET_USER" 2>/dev/null | cut -d: -f6)"
  [ -n "$TARGET_HOME" ] || TARGET_HOME="/home/$TARGET_USER"
  printf '\n[HIVE MIND] sudo detected. Installing for desktop user %s instead of root.\n' "$TARGET_USER"
  exec sudo -u "$TARGET_USER" -H env -u SUDO_USER -u SUDO_UID -u SUDO_GID HOME="$TARGET_HOME" bash "$0" "$@"
fi

HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$HERE/payload"
DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
CONFIG_HOME="${XDG_CONFIG_HOME:-$HOME/.config}"
STATE_HOME="${XDG_STATE_HOME:-$HOME/.local/state}"
APP_ROOT="$DATA_HOME/HiveMind"
APP_DIR="$APP_ROOT/app"
DATA_DIR="$APP_ROOT/data"
CONFIG_DIR="$CONFIG_HOME/HiveMind"
STATE_DIR="$STATE_HOME/HiveMind"
BIN_DIR="$HOME/.local/bin"
DESKTOP_APPS="$DATA_HOME/applications"
AUTOSTART_DIR="$CONFIG_HOME/autostart"
DESKTOP_DIR="${XDG_DESKTOP_DIR:-$HOME/Desktop}"

say(){ printf '\n[%s] %s\n' "$APP_NAME" "$*"; }
warn(){ printf '\n[%s] WARNING: %s\n' "$APP_NAME" "$*" >&2; }
fail(){ printf '\n[%s] ERROR: %s\n' "$APP_NAME" "$*" >&2; exit 1; }
has(){ command -v "$1" >/dev/null 2>&1; }

[ -d "$PAYLOAD" ] || fail "Installer payload was not found next to this script. Extract the full ZIP first."
mkdir -p "$APP_ROOT" "$DATA_DIR" "$CONFIG_DIR" "$STATE_DIR" "$BIN_DIR" "$DESKTOP_APPS"

say "Installing HIVE MIND $VERSION for Linux..."

# HIVE MIND dependencies currently require CPython 3.10-3.13.
# Python 3.14 is intentionally rejected because the pinned pydantic-core/PyO3
# toolchain in this release does not support it yet.
python_compatible(){
  "$1" - <<'PY' >/dev/null 2>&1
import sys
raise SystemExit(0 if (3,10) <= sys.version_info[:2] < (3,14) else 1)
PY
}

choose_python(){
  local candidate
  for candidate in python3.13 python3.12 python3.11 python3.10 python3; do
    if has "$candidate" && python_compatible "$candidate"; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  return 1
}

PYTHON_BIN="$(choose_python || true)"
if [ -z "$PYTHON_BIN" ]; then
  say "A HIVE MIND-compatible Python (3.10-3.13) was not found. Attempting to install one..."
  if has dnf; then
    # Fedora/RHEL family: try newest compatible interpreters first.
    for pkg in python3.13 python3.12 python3.11 python3.10; do
      sudo dnf install -y "$pkg" >/dev/null 2>&1 || continue
      PYTHON_BIN="$(choose_python || true)"
      [ -n "$PYTHON_BIN" ] && break
    done
  elif has apt-get; then
    sudo apt-get update
    # Debian/Ubuntu: installed distro Python is usually already compatible;
    # try available versioned packages without adding third-party repositories.
    for pkg in python3.13 python3.12 python3.11 python3.10; do
      sudo apt-get install -y "$pkg" "${pkg}-venv" >/dev/null 2>&1 || continue
      PYTHON_BIN="$(choose_python || true)"
      [ -n "$PYTHON_BIN" ] && break
    done
  fi
fi

[ -n "$PYTHON_BIN" ] || fail "HIVE MIND requires Python 3.10 through 3.13. Python 3.14 is not supported by this build. Install Python 3.13 or 3.12 and rerun the installer."
PYTHON_VERSION="$($PYTHON_BIN -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")')"
say "Using $PYTHON_BIN ($PYTHON_VERSION)."

# Verify that venv can ACTUALLY create an environment. `python -m venv --help`
# is not sufficient on Debian/Kali because the venv module may exist while the
# separately packaged ensurepip payload is missing.
venv_probe="$(mktemp -d)"
venv_err="$venv_probe/venv-error.txt"
if ! "$PYTHON_BIN" -m venv "$venv_probe/test" 2>"$venv_err"; then
  say "Installing the Python virtual-environment support required by $PYTHON_BIN..."
  rm -rf "$venv_probe/test"
  if has apt-get; then
    sudo apt-get update
    # Kali/Debian/Ubuntu versioned Python packages use pythonX.Y-venv.
    if ! sudo apt-get install -y "${PYTHON_BIN}-venv"; then
      # If the selected command is an unversioned python3, use the distro meta package.
      sudo apt-get install -y python3-venv || true
    fi
  elif has dnf; then
    # Fedora generally ships ensurepip with Python, but these packages cover
    # minimal installs and versioned interpreter layouts.
    sudo dnf install -y "${PYTHON_BIN}-pip" 2>/dev/null || sudo dnf install -y python3-pip || true
  fi
  if ! "$PYTHON_BIN" -m venv "$venv_probe/test" 2>"$venv_err"; then
    detail="$(tail -n 8 "$venv_err" 2>/dev/null || true)"
    rm -rf "$venv_probe"
    fail "Could not create a Python virtual environment with $PYTHON_BIN after installing venv support. ${detail}"
  fi
fi
rm -rf "$venv_probe"

# Stop only an installed HIVE MIND process before replacing application files.
if [ -f "$STATE_DIR/hive-mind.pid" ]; then
  oldpid="$(cat "$STATE_DIR/hive-mind.pid" 2>/dev/null || true)"
  if [ -n "$oldpid" ] && kill -0 "$oldpid" 2>/dev/null; then
    cmd="$(ps -p "$oldpid" -o args= 2>/dev/null || true)"
    if [[ "$cmd" == *"$APP_DIR"*"run.py"* ]]; then
      say "Stopping existing HIVE MIND process..."
      kill "$oldpid" 2>/dev/null || true
      for _ in {1..20}; do kill -0 "$oldpid" 2>/dev/null || break; sleep 0.25; done
    fi
  fi
fi

# Replace app code, never persistent data.
say "Installing application files into $APP_DIR"
tmp="$APP_ROOT/.app-new-$$"
rm -rf "$tmp"
mkdir -p "$tmp"
cp -a "$PAYLOAD/." "$tmp/"
rm -rf "$APP_DIR.old"
if [ -d "$APP_DIR" ]; then mv "$APP_DIR" "$APP_DIR.old"; fi
mv "$tmp" "$APP_DIR"
rm -rf "$APP_DIR.old"

# Linux persistent settings. Existing data is intentionally preserved.
cat > "$APP_DIR/.env" <<ENV
HIVE_DATA_DIR=$DATA_DIR
HIVE_HOST=$HOST
HIVE_PORT=$PORT
HIVE_ALLOWED_HOSTS=127.0.0.1,localhost
HIVE_MAX_UPLOAD_MB=20480
HIVE_MAX_FILES_PER_UPLOAD=50
HIVE_LOCAL_LLM_URL=http://127.0.0.1:$OLLAMA_PORT/api/chat
HIVE_LOCAL_LLM_MODEL=$MODEL
HIVE_ENABLE_LLM=true
HIVE_REQUIRE_MALWARE_SCANNER=false
HIVE_COOKIE_SECURE=false
ENV
chmod 600 "$APP_DIR/.env"

# Create/update virtual environment. If an earlier installer created it with
# Python 3.14, discard only the venv and rebuild it with the compatible interpreter.
say "Preparing the private Python environment..."
rebuild_venv=0
if [ -x "$APP_DIR/.venv/bin/python" ]; then
  if ! python_compatible "$APP_DIR/.venv/bin/python"; then
    say "Replacing incompatible Python virtual environment..."
    rebuild_venv=1
  else
    venv_mm="$($APP_DIR/.venv/bin/python -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
    selected_mm="$($PYTHON_BIN -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
    [ "$venv_mm" = "$selected_mm" ] || rebuild_venv=1
  fi
else
  rebuild_venv=1
fi
if [ "$rebuild_venv" -eq 1 ]; then
  rm -rf "$APP_DIR/.venv"
  "$PYTHON_BIN" -m venv "$APP_DIR/.venv"
fi
printf '%s\n' "$PYTHON_BIN" > "$APP_DIR/.python-bin"
"$APP_DIR/.venv/bin/python" -m pip install --disable-pip-version-check --upgrade pip setuptools wheel >/dev/null
"$APP_DIR/.venv/bin/python" -m pip install --disable-pip-version-check --prefer-binary -r "$APP_DIR/backend/requirements.txt"

# Provision Ollama if possible. If offline, leave a clear warning rather than failing HIVE MIND installation.
if ! has ollama; then
  say "Ollama was not found. Attempting the official Linux installation..."
  if has curl && curl -fsS --connect-timeout 5 https://ollama.com/ >/dev/null 2>&1; then
    if curl -fsSL https://ollama.com/install.sh | sh; then :; else warn "Ollama installation did not complete."; fi
  else
    warn "Ollama could not be installed while offline. HIVE MIND will still install; local AI will become available after Ollama is installed."
  fi
fi

# Launcher used by desktop/menu shortcuts.
cat > "$BIN_DIR/hive-mind" <<'LAUNCHER'
#!/usr/bin/env bash
set -u
HOST="127.0.0.1"
PORT="8787"
OLLAMA_PORT="11434"
MODEL="llama3.2:3b"
DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
STATE_HOME="${XDG_STATE_HOME:-$HOME/.local/state}"
APP_ROOT="$DATA_HOME/HiveMind"
APP_DIR="$APP_ROOT/app"
STATE_DIR="$STATE_HOME/HiveMind"
LOG="$STATE_DIR/quick-start.log"
PIDFILE="$STATE_DIR/hive-mind.pid"
NO_BROWSER=0
[ "${1:-}" = "--background" ] && NO_BROWSER=1
mkdir -p "$STATE_DIR"
exec >>"$LOG" 2>&1
printf '\n=== HIVE MIND Quick Start %s ===\n' "$(date -Is)"
notify(){ if command -v notify-send >/dev/null 2>&1; then notify-send "HIVE MIND" "$1" >/dev/null 2>&1 || true; fi; }
url_ok(){ curl -fsS --max-time 2 "$1" >/dev/null 2>&1; }
open_browser(){
  [ "$NO_BROWSER" -eq 1 ] && return 0
  if command -v xdg-open >/dev/null 2>&1; then xdg-open "http://$HOST:$PORT" >/dev/null 2>&1 &
  elif command -v gio >/dev/null 2>&1; then gio open "http://$HOST:$PORT" >/dev/null 2>&1 &
  fi
}

[ -x "$APP_DIR/.venv/bin/python" ] || { notify "Installation is incomplete. Run INSTALL_HIVE_MIND.sh again."; exit 2; }

# Start local Ollama without requiring a second shortcut.
if ! url_ok "http://$HOST:$OLLAMA_PORT/api/tags"; then
  if command -v ollama >/dev/null 2>&1; then
    export OLLAMA_HOST="$HOST:$OLLAMA_PORT"
    nohup ollama serve >>"$STATE_DIR/ollama.log" 2>&1 &
    for _ in {1..40}; do url_ok "http://$HOST:$OLLAMA_PORT/api/tags" && break; sleep 0.5; done
  fi
fi

# Pull the configured model if Ollama is online but the model is absent.
if url_ok "http://$HOST:$OLLAMA_PORT/api/tags" && command -v ollama >/dev/null 2>&1; then
  if ! ollama list 2>/dev/null | awk 'NR>1{print $1}' | grep -Fxq "$MODEL"; then
    notify "Preparing local AI model. First start may take several minutes."
    ollama pull "$MODEL" >>"$STATE_DIR/ollama-model.log" 2>&1 || true
  fi
fi

# Do not create duplicate HIVE MIND backends.
if url_ok "http://$HOST:$PORT/api/health"; then
  open_browser
  exit 0
fi

if [ -f "$PIDFILE" ]; then
  pid="$(cat "$PIDFILE" 2>/dev/null || true)"
  if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
    cmd="$(ps -p "$pid" -o args= 2>/dev/null || true)"
    if [[ "$cmd" == *"$APP_DIR"*"run.py"* ]]; then
      for _ in {1..60}; do url_ok "http://$HOST:$PORT/api/health" && { open_browser; exit 0; }; sleep 0.5; done
      notify "HIVE MIND is running but did not become ready. See $LOG"
      exit 3
    fi
  fi
fi

cd "$APP_DIR" || exit 4
nohup "$APP_DIR/.venv/bin/python" "$APP_DIR/run.py" >>"$STATE_DIR/server.log" 2>&1 &
pid=$!
printf '%s\n' "$pid" > "$PIDFILE"

for _ in {1..80}; do
  if url_ok "http://$HOST:$PORT/api/health"; then
    open_browser
    exit 0
  fi
  kill -0 "$pid" 2>/dev/null || break
  sleep 0.5
done
notify "HIVE MIND could not start. See $STATE_DIR/server.log"
exit 5
LAUNCHER
chmod 755 "$BIN_DIR/hive-mind"

# Convenience stop command.
cat > "$BIN_DIR/hive-mind-stop" <<'STOPPER'
#!/usr/bin/env bash
STATE_HOME="${XDG_STATE_HOME:-$HOME/.local/state}"
PIDFILE="$STATE_HOME/HiveMind/hive-mind.pid"
if [ -f "$PIDFILE" ]; then
  pid="$(cat "$PIDFILE" 2>/dev/null || true)"
  if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then kill "$pid" 2>/dev/null || true; fi
  rm -f "$PIDFILE"
fi
STOPPER
chmod 755 "$BIN_DIR/hive-mind-stop"

ICON="$APP_DIR/frontend/assets/hive-mind-logo.png"
cat > "$DESKTOP_APPS/hive-mind.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=HIVE MIND
Comment=Secure offline organizational knowledge system
Exec=$BIN_DIR/hive-mind
Icon=$ICON
Terminal=false
Categories=Office;Utility;
StartupNotify=true
DESKTOP
chmod 644 "$DESKTOP_APPS/hive-mind.desktop"

# Optional visible desktop icon when a Desktop directory exists.
if [ -d "$DESKTOP_DIR" ]; then
  cp "$DESKTOP_APPS/hive-mind.desktop" "$DESKTOP_DIR/HIVE MIND.desktop" 2>/dev/null || true
  chmod +x "$DESKTOP_DIR/HIVE MIND.desktop" 2>/dev/null || true
  if has gio; then gio set "$DESKTOP_DIR/HIVE MIND.desktop" metadata::trusted true >/dev/null 2>&1 || true; fi
fi

has update-desktop-database && update-desktop-database "$DESKTOP_APPS" >/dev/null 2>&1 || true

# Try to bring Ollama up and provision the model during installation while the terminal is visible.
if has ollama; then
  if ! curl -fsS --max-time 2 "http://$HOST:$OLLAMA_PORT/api/tags" >/dev/null 2>&1; then
    export OLLAMA_HOST="$HOST:$OLLAMA_PORT"
    nohup ollama serve >>"$STATE_DIR/ollama.log" 2>&1 &
    for _ in {1..30}; do curl -fsS --max-time 2 "http://$HOST:$OLLAMA_PORT/api/tags" >/dev/null 2>&1 && break; sleep 0.5; done
  fi
  if curl -fsS --max-time 2 "http://$HOST:$OLLAMA_PORT/api/tags" >/dev/null 2>&1; then
    if ! ollama list 2>/dev/null | awk 'NR>1{print $1}' | grep -Fxq "$MODEL"; then
      say "Downloading the local $MODEL model..."
      ollama pull "$MODEL" || warn "Model download failed. Quick Start will retry later."
    fi
  fi
fi

printf '\nStart HIVE MIND automatically when you sign in to Linux? [y/N] '
read -r startup || startup=""
if [[ "$startup" =~ ^[Yy]$ ]]; then
  mkdir -p "$AUTOSTART_DIR"
  cat > "$AUTOSTART_DIR/hive-mind.desktop" <<AUTO
[Desktop Entry]
Type=Application
Name=HIVE MIND
Exec=$BIN_DIR/hive-mind --background
Icon=$ICON
Terminal=false
X-GNOME-Autostart-enabled=true
AUTO
  chmod 644 "$AUTOSTART_DIR/hive-mind.desktop"
else
  rm -f "$AUTOSTART_DIR/hive-mind.desktop" 2>/dev/null || true
fi

say "Installation complete."
echo "Application: $APP_DIR"
echo "Persistent data: $DATA_DIR"
echo "Launcher: $BIN_DIR/hive-mind"
echo "Menu shortcut: HIVE MIND"
printf '\nLaunch HIVE MIND now? [Y/n] '
read -r launch || launch=""
if [ -z "$launch" ] || [[ "$launch" =~ ^[Yy]$ ]]; then "$BIN_DIR/hive-mind" >/dev/null 2>&1 & fi
