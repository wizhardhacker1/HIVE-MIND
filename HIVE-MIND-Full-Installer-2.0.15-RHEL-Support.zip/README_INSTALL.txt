HIVE MIND 2.0.15 — WINDOWS + DEBIAN/KALI + RHEL FULL INSTALLER

WINDOWS
1. Extract the ZIP.
2. Double-click INSTALL_HIVE_MIND.bat.
3. Use the HIVE MIND desktop shortcut for one-click startup.

KALI / DEBIAN / UBUNTU
1. Extract the ZIP.
2. chmod +x INSTALL_HIVE_MIND.sh
3. sudo ./INSTALL_HIVE_MIND.sh

RHEL / ROCKY / ALMALINUX / CENTOS STREAM / ORACLE LINUX
1. Extract the ZIP.
2. chmod +x INSTALL_HIVE_MIND_RHEL.sh
3. sudo ./INSTALL_HIVE_MIND_RHEL.sh

The RHEL installer uses dnf/yum, preserves SELinux, installs HIVE MIND into the invoking user's ~/.local/share/HiveMind tree, and keeps persistent data in ~/.local/share/HiveMind/data.

HIVE MIND uses Meta Llama 3.2 3B through a loopback-only Ollama service for local/offline chat. The model is downloaded during provisioning when Internet access is available and is not embedded in this ZIP.
