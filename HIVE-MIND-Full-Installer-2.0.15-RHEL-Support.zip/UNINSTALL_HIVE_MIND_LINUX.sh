#!/usr/bin/env bash
set -euo pipefail
DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
CONFIG_HOME="${XDG_CONFIG_HOME:-$HOME/.config}"
STATE_HOME="${XDG_STATE_HOME:-$HOME/.local/state}"
"$HOME/.local/bin/hive-mind-stop" 2>/dev/null || true
rm -f "$HOME/.local/bin/hive-mind" "$HOME/.local/bin/hive-mind-stop"
rm -f "$DATA_HOME/applications/hive-mind.desktop" "$CONFIG_HOME/autostart/hive-mind.desktop"
rm -f "$HOME/Desktop/HIVE MIND.desktop" 2>/dev/null || true
rm -rf "$DATA_HOME/HiveMind/app" "$CONFIG_HOME/HiveMind" "$STATE_HOME/HiveMind"
echo "HIVE MIND application removed. Persistent vault data was kept at: $DATA_HOME/HiveMind/data"
