HIVE MIND 2.0.13 — WINDOWS + LINUX FULL INSTALLER

WINDOWS
1. Extract this ZIP.
2. Double-click INSTALL_HIVE_MIND.bat.
3. Use the HIVE MIND desktop shortcut for one-click startup.
4. App files: %LOCALAPPDATA%\HiveMind\app
5. Persistent data: %LOCALAPPDATA%\HiveMind\data

LINUX
1. Extract this ZIP.
2. Open a terminal in the extracted folder.
3. Run: chmod +x INSTALL_HIVE_MIND.sh && ./INSTALL_HIVE_MIND.sh
4. After installation, launch HIVE MIND from the application menu or desktop icon.
5. App files: ~/.local/share/HiveMind/app
6. Persistent data: ~/.local/share/HiveMind/data
7. Command-line Quick Start: ~/.local/bin/hive-mind

The Linux installer can provision Ollama when package/network access is available and uses the local Meta Llama 3.2 3B model. HIVE MIND itself remains loopback-only by default.
